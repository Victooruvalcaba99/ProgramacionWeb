<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

if (!esAdmin()) redirigir('/WebPageUpdate/habitos/home/index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre   = limpiar($_POST['nombre']   ?? '');
    $usuario  = limpiar($_POST['usuario']  ?? '');
    $password = $_POST['password'] ?? '';
    $id_rol   = (int)($_POST['id_rol']    ?? 2);

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, usuario, password, id_rol) VALUES (:nombre, :usuario, :password, :id_rol)");
    $stmt->execute([':nombre' => $nombre, ':usuario' => $usuario, ':password' => $hash, ':id_rol' => $id_rol]);

    redirigir('/WebPageUpdate/habitos/home/usuarios/index.php');
}

$pageTitle = 'Registrar Usuario | LexEconomica';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<main class="main-content">
    <div class="section-container">
        <h1>Registrar Nuevo Usuario</h1>
        <form method="post" class="form-card">
            <div class="form-group">
                <label for="nombre">Nombre completo</label>
                <input type="text" name="nombre" id="nombre" required>
            </div>
            <div class="form-group">
                <label for="usuario">Usuario</label>
                <input type="text" name="usuario" id="usuario" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div class="form-group">
                <label for="id_rol">Rol</label>
                <select name="id_rol" id="id_rol">
                    <option value="2">Becario</option>
                    <option value="1">Administrador</option>
                </select>
            </div>
            <input type="submit" value="Registrar →">
        </form>
        <a href="/WebPageUpdate/habitos/home/usuarios/index.php">← Volver</a>
    </div>
</main>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
