<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

// Solo administradores
if (!esAdmin()) {
    redirigir('/WebPageUpdate/habitos/home/index.php');
}

$stmt = $pdo->query("SELECT id, nombre, usuario, id_rol FROM usuarios ORDER BY id DESC");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Usuarios | LexEconomica';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<main class="main-content">
    <div class="section-container">
        <div class="section-header">
            <h1>Gestión de Usuarios</h1>
            <a href="/WebPageUpdate/habitos/home/usuarios/registrar.php" class="btn-primary">+ Nuevo Usuario</a>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Usuario</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><?php echo $u['id']; ?></td>
                    <td><?php echo limpiar($u['nombre']); ?></td>
                    <td><?php echo limpiar($u['usuario']); ?></td>
                    <td><?php echo $u['id_rol'] == 1 ? 'Admin' : 'Becario'; ?></td>
                    <td class="actions">
                        <a href="/WebPageUpdate/habitos/home/usuarios/editar.php?id=<?php echo $u['id']; ?>">Editar</a>
                        <a href="/WebPageUpdate/habitos/home/usuarios/eliminar.php?id=<?php echo $u['id']; ?>" onclick="return confirm('¿Eliminar usuario?')">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
