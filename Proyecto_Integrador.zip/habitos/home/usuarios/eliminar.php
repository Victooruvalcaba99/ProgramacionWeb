<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

if (!esAdmin()) redirigir('/WebPageUpdate/habitos/home/index.php');

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = :id");
$stmt->execute([':id' => $id]);

redirigir('/WebPageUpdate/habitos/home/usuarios/index.php');
