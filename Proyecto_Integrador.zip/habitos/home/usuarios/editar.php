<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

if (!esAdmin()) redirigir('/WebPageUpdate/habitos/home/index.php');

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre  = limpiar($_POST['nombre']  ?? '');
    $usuario = limpiar($_POST['usuario'] ?? '');
    $id_rol  = (int)($_POST['id_rol']   ?? 2);

    $stmt = $pdo->prepare("UPDATE usuarios SET nombre = :nombre, usuario = :usuario, id_rol = :id_rol WHERE id = :id");
    $stmt->execute([':nombre' => $nombre, ':usuario' => $usuario, ':id_rol' => $id_rol, ':id' => $id]);

    redirigir('/WebPageUpdate/habitos/home/usuarios/index.php');
}

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
$stmt->execute([':id' => $id]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$u) redirigir('/WebPageUpdate/habitos/home/usuarios/index.php');

$pageTitle = 'Editar Usuario | LexEconomica';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<main class="main-content">
    <div class="section-container">
        <h1>Editar Usuario</h1>
        <form method="post" class="form-card">
            <div class="form-group">
                <label for="nombre">Nombre completo</label>
                <input type="text" name="nombre" id="nombre" value="<?php echo limpiar($u['nombre']); ?>" required>
            </div>
            <div class="form-group">
                <label for="usuario">Usuario</label>
                <input type="text" name="usuario" id="usuario" value="<?php echo limpiar($u['usuario']); ?>" required>
            </div>
            <div class="form-group">
                <label for="id_rol">Rol</label>
                <select name="id_rol" id="id_rol">
                    <option value="2" <?php echo $u['id_rol'] == 2 ? 'selected' : ''; ?>>Becario</option>
                    <option value="1" <?php echo $u['id_rol'] == 1 ? 'selected' : ''; ?>>Administrador</option>
                </select>
            </div>
            <input type="submit" value="Guardar cambios →">
        </form>
        <a href="/WebPageUpdate/habitos/home/usuarios/index.php">← Volver</a>
    </div>
</main>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
