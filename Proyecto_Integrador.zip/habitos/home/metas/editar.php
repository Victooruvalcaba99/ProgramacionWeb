<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$id_meta    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error      = '';

// Fetch existing
$stmt = $pdo->prepare("SELECT * FROM metas WHERE id = :id AND id_usuario = :u");
$stmt->execute([':id' => $id_meta, ':u' => $id_usuario]);
$meta = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$meta) {
    header('Location: /WebPageUpdate/habitos/home/metas/index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['eliminar_meta'])) {
        $stmtD = $pdo->prepare("DELETE FROM metas WHERE id = :id AND id_usuario = :u");
        $stmtD->execute([':id' => $id_meta, ':u' => $id_usuario]);
        header('Location: /WebPageUpdate/habitos/home/metas/index.php');
        exit();
    }

    $titulo       = limpiar($_POST['titulo'] ?? '');
    $descripcion  = limpiar($_POST['descripcion'] ?? '');
    $fecha_inicio = empty($_POST['fecha_inicio']) ? date('Y-m-d') : $_POST['fecha_inicio'];
    $fecha_limite = empty($_POST['fecha_limite']) ? null : $_POST['fecha_limite'];
    
    // WhatsApp Fields
    $wa_numero    = limpiar($_POST['wa_numero'] ?? '');
    $wa_hora      = empty($_POST['wa_hora']) ? null : $_POST['wa_hora'];
    $wa_frecuencia = in_array($_POST['wa_frecuencia'] ?? '', ['DIARIO', 'SEMANAL', 'DESACTIVADO']) ? $_POST['wa_frecuencia'] : 'DESACTIVADO';

    if (empty($titulo)) {
        $error = 'El título de la meta es obligatorio.';
    } else {
        $stmtU = $pdo->prepare(
            "UPDATE metas 
             SET titulo = :t, descripcion = :d, fecha_inicio = :fi, fecha_limite = :fl,
                 wa_numero = :wn, wa_hora = :wh, wa_frecuencia = :wf
             WHERE id = :id AND id_usuario = :u"
        );
        $stmtU->execute([
            ':t'  => $titulo,
            ':d'  => $descripcion,
            ':fi' => $fecha_inicio,
            ':fl' => $fecha_limite,
            ':wn' => $wa_numero,
            ':wh' => $wa_hora,
            ':wf' => $wa_frecuencia,
            ':id' => $id_meta,
            ':u'  => $id_usuario
        ]);
        header('Location: /WebPageUpdate/habitos/home/metas/index.php');
        exit();
    }
}

$pageTitle = 'Editar Meta | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="columns is-centered">
      <div class="column is-6">
        
        <div class="is-flex is-justify-content-space-between is-align-items-center mb-4">
            <h1 class="title is-3" style="color: var(--secondary);">✏️ Editar Meta</h1>
            <a href="/WebPageUpdate/habitos/home/metas/index.php" class="button is-light is-small">Cancelar</a>
        </div>

        <?php if ($error): ?>
          <div class="notification is-danger is-light"><?php echo limpiar($error); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-content">
                <form method="post">
                  
                  <div class="field mb-4">
                    <label class="label">Título de la meta <span class="has-text-danger">*</span></label>
                    <div class="control">
                      <input class="input is-medium" type="text" name="titulo" value="<?php echo limpiar($meta['titulo']); ?>" required autocomplete="off">
                    </div>
                  </div>

                  <div class="field mb-4">
                    <label class="label">Descripción</label>
                    <div class="control">
                      <textarea class="textarea" name="descripcion" rows="3"><?php echo limpiar($meta['descripcion']); ?></textarea>
                    </div>
                  </div>

                  <div class="columns">
                      <div class="column is-6">
                        <div class="field mb-5">
                          <label class="label">Fecha de inicio</label>
                          <div class="control">
                            <input class="input" type="date" name="fecha_inicio" value="<?php echo htmlspecialchars($meta['fecha_inicio'] ?? date('Y-m-d')); ?>">
                          </div>
                        </div>
                      </div>
                      <div class="column is-6">
                        <div class="field mb-5">
                          <label class="label">Fecha de término (opcional)</label>
                          <div class="control">
                            <input class="input" type="date" name="fecha_limite" value="<?php echo htmlspecialchars($meta['fecha_limite'] ?? ''); ?>">
                          </div>
                        </div>
                      </div>
                  </div>

                  <!-- WhatsApp Notification Center -->
                  <div class="box has-background-success-light" style="border: 1px solid #48c774; border-radius: 8px;">
                      <h3 class="title is-5 mb-2" style="color: #25d366;">
                          <span class="material-symbols-outlined is-size-4" style="vertical-align: middle;">chat</span> Notificaciones vía WhatsApp
                      </h3>
                      <p class="is-size-7 has-text-grey mb-4">
                          Recibe recordatorios automáticos sobre esta meta directamente en tu teléfono.
                      </p>

                      <div class="columns is-multiline">
                          <div class="column is-12">
                              <div class="field">
                                  <label class="label is-small">Número de WhatsApp</label>
                                  <div class="field has-addons">
                                      <div class="control">
                                          <div class="select is-small">
                                              <select id="wa_pais">
                                                  <option value="521">🇲🇽 +521</option>
                                                  <option value="57">🇨🇴 +57</option>
                                                  <option value="54">🇦🇷 +54</option>
                                                  <option value="34">🇪🇸 +34</option>
                                                  <option value="1">🇺🇸 +1</option>
                                                  <option value="51">🇵🇪 +51</option>
                                                  <option value="56">🇨🇱 +56</option>
                                                  <option value="593">🇪🇨 +593</option>
                                                  <option value="58">🇻🇪 +58</option>
                                              </select>
                                          </div>
                                      </div>
                                      <div class="control is-expanded">
                                          <input class="input is-small" type="tel" id="wa_num_solo" placeholder="ej. 5512345678" value="">
                                      </div>
                                  </div>
                                  <input type="hidden" name="wa_numero" id="wa_numero_full" value="<?php echo htmlspecialchars($meta['wa_numero'] ?? ''); ?>">
                                  <p class="help">Selecciona tu país e ingresa los 10 dígitos de tu celular.</p>
                              </div>
                              <button type="button" id="btn-test-wa" class="button is-small is-success is-outlined is-fullwidth mt-2" onclick="probarWhatsApp()">
                                  <span class="material-symbols-outlined is-size-6 mr-1">send</span> Probar Notificación Ahora
                              </button>
                          </div>
                          
                          <div class="column is-6">
                              <div class="field">
                                  <label class="label is-small">Hora de Envío</label>
                                  <div class="control">
                                      <input class="input" type="time" name="wa_hora" value="<?php echo htmlspecialchars($meta['wa_hora'] ?? ''); ?>">
                                  </div>
                              </div>
                          </div>

                          <div class="column is-6">
                              <div class="field">
                                  <label class="label is-small">Frecuencia</label>
                                  <div class="control">
                                      <div class="select is-fullwidth">
                                          <select name="wa_frecuencia">
                                              <option value="DESACTIVADO" <?php echo ($meta['wa_frecuencia'] === 'DESACTIVADO') ? 'selected' : ''; ?>>🔕 Desactivado</option>
                                              <option value="DIARIO" <?php echo ($meta['wa_frecuencia'] === 'DIARIO') ? 'selected' : ''; ?>>📅 Diario</option>
                                              <option value="SEMANAL" <?php echo ($meta['wa_frecuencia'] === 'SEMANAL') ? 'selected' : ''; ?>>📆 Semanal</option>
                                          </select>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="control mt-4">
                    <button type="submit" class="button is-primary is-medium is-fullwidth mb-3">
                        💾 Guardar Cambios
                    </button>
                    <button type="submit" name="eliminar_meta" class="button is-danger is-light is-fullwidth" onclick="return confirm('¿Seguro que deseas eliminar esta meta? Los hábitos asociados no se borrarán, pero perderán el vínculo.');">
                        🗑️ Eliminar Meta
                    </button>
                  </div>
                </form>
            </div>
        </div>

      </div>
    </div>
  </div>
</section>

<script>
// Al cargar la página, intentar separar el código de país del número si ya existe
document.addEventListener('DOMContentLoaded', () => {
    const fullNum = document.getElementById('wa_numero_full').value;
    if (fullNum) {
        // Lógica simple: buscar si el número empieza por alguno de los códigos conocidos
        const select = document.getElementById('wa_pais');
        const options = Array.from(select.options).map(o => o.value).sort((a,b) => b.length - a.length);
        
        for (let code of options) {
            if (fullNum.startsWith(code)) {
                select.value = code;
                document.getElementById('wa_num_solo').value = fullNum.substring(code.length);
                break;
            }
        }
    }
});

// Función para unir el código y el número antes de guardar o probar
function obtenerNumeroCompleto() {
    const pais = document.getElementById('wa_pais').value;
    const num = document.getElementById('wa_num_solo').value.replace(/[^0-9]/g, '');
    const full = pais + num;
    document.getElementById('wa_numero_full').value = full;
    return full;
}

async function probarWhatsApp() {
    const fullNum = obtenerNumeroCompleto();
    if (fullNum.length < 10) {
        alert('Por favor ingresa un número de teléfono válido.');
        return;
    }
    
    const btn = document.getElementById('btn-test-wa');
    btn.classList.add('is-loading');
    
    try {
        const resp = await fetch('/WebPageUpdate/habitos/api/metas/test_wa.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                id_meta: <?php echo $id_meta; ?>,
                numero: fullNum
            })
        });
        const data = await resp.json();
        
        if (data.success) {
            alert('✅ ¡Mensaje de prueba enviado! Revisa tu WhatsApp.');
        } else {
            alert('❌ Error: ' + (data.error || 'No se pudo enviar el mensaje. Revisa tu ID de Instancia y Token.'));
        }
    } catch (e) {
        alert('❌ Error de conexión al intentar enviar el mensaje.');
    } finally {
        btn.classList.remove('is-loading');
    }
}

// Asegurarse de actualizar el campo oculto antes de enviar el formulario principal
document.querySelector('form').addEventListener('submit', () => {
    obtenerNumeroCompleto();
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
