<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo       = limpiar($_POST['titulo'] ?? '');
    $descripcion  = limpiar($_POST['descripcion'] ?? '');
    $fecha_inicio = empty($_POST['fecha_inicio']) ? date('Y-m-d') : $_POST['fecha_inicio'];
    $fecha_limite = empty($_POST['fecha_limite']) ? null : $_POST['fecha_limite'];

    if (empty($titulo)) {
        $error = 'El título de la meta es obligatorio.';
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO metas (id_usuario, titulo, descripcion, fecha_inicio, fecha_limite)
             VALUES (:u, :t, :d, :fi, :fl)"
        );
        $stmt->execute([
            ':u'  => $id_usuario,
            ':t'  => $titulo,
            ':d'  => $descripcion,
            ':fi' => $fecha_inicio,
            ':fl' => $fecha_limite,
        ]);
        header('Location: /WebPageUpdate/habitos/home/metas/index.php');
        exit();
    }
}

$pageTitle = 'Crear Meta | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="columns is-centered">
      <div class="column is-6">
        
        <div class="is-flex is-justify-content-space-between is-align-items-center mb-4">
            <h1 class="title is-3" style="color: var(--secondary);">🎯 Crear Nueva Meta</h1>
            <a href="/WebPageUpdate/habitos/home/metas/index.php" class="button is-light is-small">Cancelar</a>
        </div>

        <?php if ($error): ?>
          <div class="notification is-danger is-light"><?php echo limpiar($error); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-content">
                <form method="post">
                  
                  <div class="field mb-4">
                    <label class="label">Título de la meta <span class="has-text-danger">*</span></label>
                    <div class="control">
                      <input class="input is-medium" type="text" name="titulo" placeholder="ej. Correr mi primera maratón" required autocomplete="off">
                    </div>
                  </div>

                  <div class="field mb-4">
                    <label class="label">Descripción</label>
                    <div class="control">
                      <textarea class="textarea" name="descripcion" rows="3" placeholder="¿Cómo planeas lograrlo?"></textarea>
                    </div>
                  </div>

                  <div class="columns">
                      <div class="column is-6">
                        <div class="field mb-5">
                          <label class="label">Fecha de inicio</label>
                          <div class="control">
                            <input class="input" type="date" name="fecha_inicio" value="<?php echo date('Y-m-d'); ?>">
                          </div>
                        </div>
                      </div>
                      <div class="column is-6">
                        <div class="field mb-5">
                          <label class="label">Fecha de término (opcional)</label>
                          <div class="control">
                            <input class="input" type="date" name="fecha_limite">
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="control">
                    <button type="submit" class="button is-primary is-medium is-fullwidth">
                        💾 Guardar Meta
                    </button>
                  </div>
                </form>
            </div>
        </div>

      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
