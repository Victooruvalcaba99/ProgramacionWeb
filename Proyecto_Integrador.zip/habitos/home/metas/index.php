<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = $_SESSION['usuario_id'];

// Marcar meta como completada (si hay POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['marcar_meta'])) {
    $id_meta = (int)$_POST['id_meta'];
    $stmt = $pdo->prepare("UPDATE metas SET completada = NOT completada WHERE id = :id AND id_usuario = :id_u");
    $stmt->execute([':id' => $id_meta, ':id_u' => $id_usuario]);
    header('Location: /WebPageUpdate/habitos/home/metas/index.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM metas WHERE id_usuario = :id ORDER BY completada ASC, fecha_limite ASC");
$stmt->execute([':id' => $id_usuario]);
$metas = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Mis Metas | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
    <div class="container">
        
        <div class="is-flex is-justify-content-space-between is-align-items-center mb-5">
            <div>
                <h1 class="title is-3" style="color: var(--secondary);">🎯 Mis Metas</h1>
                <p class="subtitle is-6">Objetivos a mediano y largo plazo</p>
            </div>
            <a href="/WebPageUpdate/habitos/home/metas/crear.php" class="button is-primary">+ Nueva Meta</a>
        </div>

        <?php if (empty($metas)): ?>
            <div class="notification is-light has-text-centered">
                <p>No tienes metas registradas aún. ¡Empieza a soñar en grande!</p>
            </div>
        <?php else: ?>
            <style>
            .meta-card {
                height: 100%;
                display: flex;
                flex-direction: column;
            }
            .meta-card .card-content {
                display: flex;
                flex-direction: column;
                flex-grow: 1;
            }
            .meta-card-bottom {
                margin-top: auto;
                padding-top: 15px;
            }
            </style>
            <div class="columns is-multiline is-align-items-stretch">
                <?php foreach ($metas as $m): ?>
                <div class="column is-4 is-flex">
                    <div class="card meta-card is-fullwidth <?php echo $m['completada'] ? 'has-background-light' : ''; ?>" style="width: 100%;">
                        <div class="card-content">
                            <div class="is-flex is-justify-content-space-between is-align-items-start">
                                <p class="title is-5 <?php echo $m['completada'] ? 'has-text-grey-light' : ''; ?>" style="<?php echo $m['completada'] ? 'text-decoration: line-through;' : ''; ?>; margin-bottom: 0;">
                                    <?php echo limpiar($m['titulo']); ?>
                                </p>
                                <form method="post" style="margin: 0;">
                                    <input type="hidden" name="id_meta" value="<?php echo $m['id']; ?>">
                                    <button type="submit" name="marcar_meta" class="button is-small is-rounded <?php echo $m['completada'] ? 'is-success' : 'is-light'; ?>" title="Marcar completada">
                                        <span class="material-symbols-outlined is-size-6"><?php echo $m['completada'] ? 'check_circle' : 'radio_button_unchecked'; ?></span>
                                    </button>
                                </form>
                            </div>
                            
                            <p class="subtitle is-6 mt-2 <?php echo $m['completada'] ? 'has-text-grey-light' : 'has-text-grey'; ?>">
                                <?php echo limpiar($m['descripcion']); ?>
                            </p>
                            
                            <div class="meta-card-bottom">
                                <div class="is-flex is-flex-wrap-wrap mb-4" style="gap: 10px;">
                                    <?php if ($m['fecha_inicio']): ?>
                                    <span class="tag is-info is-light">
                                        <span class="material-symbols-outlined is-size-6 mr-1" style="vertical-align: middle;">calendar_today</span> 
                                        Inicio: <?php echo date('d M', strtotime($m['fecha_inicio'])); ?>
                                    </span>
                                    <?php endif; ?>
                                    
                                    <?php if ($m['fecha_limite']): ?>
                                    <span class="tag <?php echo $m['completada'] ? 'is-light' : 'is-warning is-light'; ?>">
                                        <span class="material-symbols-outlined is-size-6 mr-1" style="vertical-align: middle;">event</span> 
                                        Término: <?php echo date('d M', strtotime($m['fecha_limite'])); ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="is-flex" style="gap: 10px;">
                                    <a href="/WebPageUpdate/habitos/home/habitos/crear.php?id_meta=<?php echo $m['id']; ?>" class="button is-small is-primary is-light is-flex-grow-1">
                                        <span class="material-symbols-outlined is-size-6 mr-1">add_task</span>
                                        Agregar hábitos
                                    </a>
                                    <a href="/WebPageUpdate/habitos/home/metas/editar.php?id=<?php echo $m['id']; ?>" class="button is-small is-light" title="Editar Meta">
                                        <span class="material-symbols-outlined is-size-6">edit</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
