<?php
require_once __DIR__ . '/../includes/verificar_sesion.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/conexion.php';

$pageTitle = 'Dashboard | HabitFlow';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/menu.php';

$id_usuario = (int)$_SESSION['usuario_id'];

// Get some stats for the dashboard summary
$stmt = $pdo->prepare("SELECT COUNT(*) FROM habitos WHERE id_usuario = :u AND archivado = 0");
$stmt->execute([':u' => $id_usuario]);
$totalHabitos = (int)$stmt->fetchColumn();

$stmtHechos = $pdo->prepare("
    SELECT COUNT(DISTINCT c.id_habito) 
    FROM completaciones c 
    JOIN habitos h ON c.id_habito = h.id 
    WHERE c.id_usuario = :u 
      AND DATE(c.completado_en) = CURDATE() 
      AND c.anulado = 0 
      AND h.archivado = 0
");
$stmtHechos->execute([':u' => $id_usuario]);
$completadosHoy = (int)$stmtHechos->fetchColumn();

$progreso = $totalHabitos > 0 ? round(($completadosHoy / $totalHabitos) * 100) : 0;
?>

<section class="section" style="padding-top: 100px;">
    <div class="container">
        
        <div class="columns is-vcentered mb-5">
            <div class="column is-8">
                <h1 class="title is-2" style="color: var(--secondary);">¡Buenos días, <?php echo limpiar($_SESSION['nombre']); ?>! 👋</h1>
                <p class="subtitle is-5">Has completado <?php echo $completadosHoy; ?> de <?php echo $totalHabitos; ?> hábitos programados para hoy.</p>
                <progress class="progress is-primary is-medium mt-3" value="<?php echo $progreso; ?>" max="100"><?php echo $progreso; ?>%</progress>
            </div>
            <div class="column is-4 has-text-right">
                <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-primary is-medium">Ver mis hábitos</a>
            </div>
        </div>

        <div class="columns is-multiline">
            
            <div class="column is-4">
                <div class="card h-100">
                    <div class="card-content">
                        <span class="material-symbols-outlined is-size-1 mb-3" style="color: var(--primary);">checklist</span>
                        <p class="title is-4">Hábitos</p>
                        <p class="subtitle is-6 mt-2">Registra y sigue tus rutinas diarias con un solo clic.</p>
                        <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-link is-light mt-3">Ir a Hábitos</a>
                    </div>
                </div>
            </div>

            <div class="column is-4">
                <div class="card h-100">
                    <div class="card-content">
                        <span class="material-symbols-outlined is-size-1 mb-3" style="color: var(--info);">calendar_month</span>
                        <p class="title is-4">Calendario</p>
                        <p class="subtitle is-6 mt-2">Visualiza tu mes completo como una agenda interactiva.</p>
                        <a href="/WebPageUpdate/habitos/home/calendario.php" class="button is-info is-light mt-3">Ver Calendario</a>
                    </div>
                </div>
            </div>

            <div class="column is-4">
                <div class="card h-100">
                    <div class="card-content">
                        <span class="material-symbols-outlined is-size-1 mb-3" style="color: var(--warning);">bar_chart</span>
                        <p class="title is-4">Reportes</p>
                        <p class="subtitle is-6 mt-2">Analiza tu progreso y visualiza tu consistencia semanal.</p>
                        <a href="/WebPageUpdate/habitos/home/habitos/reporte_semanal.php" class="button is-link is-light mt-3">Ver Reportes</a>
                    </div>
                </div>
            </div>

            <div class="column is-4">
                <div class="card h-100">
                    <div class="card-content">
                        <span class="material-symbols-outlined is-size-1 mb-3" style="color: var(--success);">flag</span>
                        <p class="title is-4">Metas</p>
                        <p class="subtitle is-6 mt-2">Define objetivos claros y monitorea tu éxito.</p>
                        <a href="/WebPageUpdate/habitos/home/metas/index.php" class="button is-link is-light mt-3">Gestionar Metas</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
