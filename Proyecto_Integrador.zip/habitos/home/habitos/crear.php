<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre          = limpiar($_POST['nombre'] ?? '');
    $descripcion     = limpiar($_POST['descripcion'] ?? '');
    $frequency_type  = in_array($_POST['frequency_type'] ?? '', ['DIARIO','SEMANAL','PERSONALIZADO'])
                       ? $_POST['frequency_type']
                       : 'DIARIO';
    $meta_cantidad   = max(1, (int)($_POST['meta_cantidad'] ?? 1));
    $fecha_inicio    = $_POST['fecha_inicio'] ?? date('Y-m-d');

    $params = null;
    if ($frequency_type === 'SEMANAL') {
        $dias = array_map('intval', $_POST['dias_semana'] ?? [1,2,3,4,5]);
        $params = json_encode(['dias' => $dias]);
    } elseif ($frequency_type === 'PERSONALIZADO') {
        $cada_n = max(1, (int)($_POST['cada_n_dias'] ?? 2));
        $params = json_encode(['cada_n_dias' => $cada_n]);
    }

    $id_meta_post    = empty($_POST['id_meta']) ? null : (int)$_POST['id_meta'];

    if (empty($nombre)) {
        $error = 'El nombre del hábito es obligatorio.';
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO habitos (id_usuario, id_meta, nombre, descripcion, frequency_type, frequency_params, meta_cantidad, fecha_inicio)
             VALUES (:u, :im, :n, :d, :ft, :fp, :mc, :fi)"
        );
        $stmt->execute([
            ':u'  => $id_usuario,
            ':im' => $id_meta_post,
            ':n'  => $nombre,
            ':d'  => $descripcion,
            ':ft' => $frequency_type,
            ':fp' => $params,
            ':mc' => $meta_cantidad,
            ':fi' => $fecha_inicio,
        ]);
        header('Location: /WebPageUpdate/habitos/home/habitos/index.php');
        exit();
    }
}

$pageTitle = 'Crear Hábito | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="columns is-centered">
      <div class="column is-6">
        
        <div class="is-flex is-justify-content-space-between is-align-items-center mb-4">
            <h1 class="title is-3" style="color: var(--secondary);">✏️ Crear Nuevo Hábito</h1>
            <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-light is-small">Cancelar</a>
        </div>
        
        <?php
        $meta_preseleccionada = isset($_GET['id_meta']) ? (int)$_GET['id_meta'] : null;
        
        $stmtMetas = $pdo->prepare("SELECT id, titulo FROM metas WHERE id_usuario = :u AND completada = 0 ORDER BY titulo ASC");
        $stmtMetas->execute([':u' => $id_usuario]);
        $metas_disponibles = $stmtMetas->fetchAll(PDO::FETCH_ASSOC);
        ?>

        <div class="notification is-info is-light">
          <strong>💡 Consejo:</strong> Los mejores hábitos son específicos y simples. Empieza con algo que puedas hacer en menos de 2 minutos.
        </div>

        <?php if ($error): ?>
          <div class="notification is-danger is-light"><?php echo limpiar($error); ?></div>
        <?php endif; ?>

        <div class="card mb-6">
            <div class="card-content">
                <form method="post">
                  
                  <div class="field mb-4">
                    <label class="label">Asignar a Meta</label>
                    <div class="is-flex is-align-items-center" style="gap: 10px;">
                        <div class="control is-expanded" style="flex-grow: 1;">
                            <div class="select is-fullwidth">
                                <select name="id_meta" id="id_meta_select">
                                    <option value="">🎯 General (Sin meta específica)</option>
                                    <?php foreach ($metas_disponibles as $m): ?>
                                        <option value="<?php echo $m['id']; ?>" <?php echo $meta_preseleccionada == $m['id'] ? 'selected' : ''; ?>>
                                            <?php echo limpiar($m['titulo']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <button type="button" class="button is-link is-light" onclick="abrirModalMeta()">
                            <span class="material-symbols-outlined is-size-6 mr-1">add</span> Nueva
                        </button>
                    </div>
                  </div>

                  <div class="field mb-4">
                    <label class="label">Nombre del hábito <span class="has-text-danger">*</span></label>
                    <div class="control">
                      <input class="input is-medium" type="text" name="nombre" placeholder="ej. Leer 10 páginas" required autocomplete="off">
                    </div>
                    <p class="help">Sé específico: "Leer 10 páginas" es mejor que "Leer más".</p>
                  </div>

                  <div class="field mb-5">
                    <label class="label">Frecuencia <span class="has-text-danger">*</span></label>
                    <div class="tabs is-toggle is-fullwidth" id="freq-tabs">
                      <ul>
                        <li class="is-active" data-freq="DIARIO">
                          <a><span>📅 Diario</span></a>
                        </li>
                        <li data-freq="SEMANAL">
                          <a><span>📆 Semanal</span></a>
                        </li>
                        <li data-freq="PERSONALIZADO">
                          <a><span>⚙️ Personalizado</span></a>
                        </li>
                      </ul>
                    </div>
                    <input type="hidden" id="frequency_type" name="frequency_type" value="DIARIO">
                  </div>

                  <div id="panel-semanal" class="box is-shadowless has-background-light mb-4" style="display:none; border: 1px solid #eee;">
                    <label class="label">Días de la semana</label>
                    <div class="field is-grouped is-grouped-multiline">
                      <?php
                      $diasNombres = [1=>'Lun',2=>'Mar',3=>'Mié',4=>'Jue',5=>'Vie',6=>'Sáb',7=>'Dom'];
                      foreach ($diasNombres as $num => $nombre):
                      ?>
                      <div class="control">
                        <label class="checkbox mr-2">
                          <input type="checkbox" name="dias_semana[]" value="<?php echo $num; ?>" <?php echo in_array($num,[1,2,3,4,5]) ? 'checked' : ''; ?>>
                          <?php echo $nombre; ?>
                        </label>
                      </div>
                      <?php endforeach; ?>
                    </div>
                  </div>

                  <div id="panel-personalizado" class="box is-shadowless has-background-light mb-4" style="display:none; border: 1px solid #eee;">
                    <div class="field">
                        <label class="label">Cada cuántos días</label>
                        <div class="control">
                            <input class="input" type="number" name="cada_n_dias" min="1" max="30" value="2">
                        </div>
                        <p class="help">ej. 2 = cada dos días</p>
                    </div>
                  </div>

                  <details class="mb-5" style="cursor: pointer;">
                    <summary class="has-text-grey has-text-weight-semibold">Más opciones (opcional)</summary>
                    <div class="box is-shadowless mt-3" style="border: 1px solid #eee;">
                        <div class="field">
                          <label class="label">Descripción</label>
                          <div class="control">
                            <textarea class="textarea has-fixed-size" name="descripcion" rows="2" placeholder="¿Por qué quieres este hábito?"></textarea>
                          </div>
                        </div>
                        <div class="field">
                          <label class="label">Meta por período</label>
                          <div class="control">
                            <input class="input" type="number" name="meta_cantidad" min="1" max="31" value="1">
                          </div>
                          <p class="help">ej. 3 = completarlo 3 veces en el período indicado.</p>
                        </div>
                        <div class="field">
                          <label class="label">Fecha de inicio</label>
                          <div class="control">
                            <input class="input" type="date" name="fecha_inicio" value="<?php echo date('Y-m-d'); ?>">
                          </div>
                        </div>
                    </div>
                  </details>

                  <div class="control">
                    <button type="submit" class="button is-primary is-medium is-fullwidth">
                        🚀 Crear Hábito
                    </button>
                  </div>
                </form>
            </div>
        </div>

      </div>
    </div>
  </div>
</section>

<script>
document.querySelectorAll('#freq-tabs li').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('#freq-tabs li').forEach(t => t.classList.remove('is-active'));
    tab.classList.add('is-active');
    
    const freq = tab.dataset.freq;
    document.getElementById('frequency_type').value = freq;
    
    document.getElementById('panel-semanal').style.display      = freq === 'SEMANAL'       ? 'block' : 'none';
    document.getElementById('panel-personalizado').style.display = freq === 'PERSONALIZADO' ? 'block' : 'none';
  });
});

function abrirModalMeta() {
    document.getElementById('modal-meta').classList.add('is-active');
    document.getElementById('nueva_meta_titulo').focus();
}

function cerrarModalMeta() {
    document.getElementById('modal-meta').classList.remove('is-active');
    document.getElementById('modal-meta-error').style.display = 'none';
}

async function guardarMetaAjax() {
    const titulo = document.getElementById('nueva_meta_titulo').value.trim();
    if (!titulo) {
        document.getElementById('modal-meta-error').textContent = 'El título es obligatorio.';
        document.getElementById('modal-meta-error').style.display = 'block';
        return;
    }
    
    const btn = document.getElementById('btn-guardar-meta');
    btn.classList.add('is-loading');
    
    try {
        const resp = await fetch('/WebPageUpdate/habitos/api/metas/crear_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                titulo: titulo,
                descripcion: document.getElementById('nueva_meta_desc').value,
                fecha_inicio: document.getElementById('nueva_meta_inicio').value,
                fecha_limite: document.getElementById('nueva_meta_fin').value
            })
        });
        const data = await resp.json();
        
        if (data.error) {
            document.getElementById('modal-meta-error').textContent = data.error;
            document.getElementById('modal-meta-error').style.display = 'block';
        } else if (data.success) {
            // Add to select and choose it
            const select = document.getElementById('id_meta_select');
            const option = document.createElement('option');
            option.value = data.id;
            option.textContent = data.titulo;
            option.selected = true;
            select.appendChild(option);
            
            // Clean and close
            document.getElementById('nueva_meta_titulo').value = '';
            document.getElementById('nueva_meta_desc').value = '';
            document.getElementById('nueva_meta_fin').value = '';
            cerrarModalMeta();
        }
    } catch (e) {
        document.getElementById('modal-meta-error').textContent = 'Error de conexión.';
        document.getElementById('modal-meta-error').style.display = 'block';
    } finally {
        btn.classList.remove('is-loading');
    }
}
</script>

<!-- Modal Nueva Meta -->
<div class="modal" id="modal-meta">
  <div class="modal-background" onclick="cerrarModalMeta()"></div>
  <div class="modal-card">
    <header class="modal-card-head">
      <p class="modal-card-title">🎯 Crear Nueva Meta</p>
      <button class="delete" aria-label="close" onclick="cerrarModalMeta()"></button>
    </header>
    <section class="modal-card-body">
      <div id="modal-meta-error" class="notification is-danger is-light" style="display: none;"></div>
      <div class="field">
        <label class="label">Título <span class="has-text-danger">*</span></label>
        <div class="control">
          <input class="input" type="text" id="nueva_meta_titulo" placeholder="ej. Bajar 5 kilos">
        </div>
      </div>
      <div class="field">
        <label class="label">Descripción</label>
        <div class="control">
          <textarea class="textarea" id="nueva_meta_desc" rows="2"></textarea>
        </div>
      </div>
      <div class="columns">
        <div class="column is-6">
          <div class="field">
            <label class="label">Fecha de Inicio</label>
            <div class="control">
              <input class="input" type="date" id="nueva_meta_inicio" value="<?php echo date('Y-m-d'); ?>">
            </div>
          </div>
        </div>
        <div class="column is-6">
          <div class="field">
            <label class="label">Fecha Límite</label>
            <div class="control">
              <input class="input" type="date" id="nueva_meta_fin">
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer class="modal-card-foot">
      <button class="button is-primary" id="btn-guardar-meta" onclick="guardarMetaAjax()">Guardar Meta</button>
      <button class="button" onclick="cerrarModalMeta()">Cancelar</button>
    </footer>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
