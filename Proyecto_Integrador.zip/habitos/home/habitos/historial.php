<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$id_habito  = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM habitos WHERE id = :h AND id_usuario = :u");
$stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
$habito = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$habito) redirigir('/WebPageUpdate/habitos/home/habitos/index.php');

$stmt = $pdo->prepare(
    "SELECT DATE(completado_en) AS dia, COUNT(*) AS veces
     FROM completaciones
     WHERE id_habito = :h AND id_usuario = :u AND anulado = 0
       AND completado_en >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY dia ORDER BY dia ASC"
);
$stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
$historial = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$rachaActual  = $habito['racha_actual'];
$rachaMaxima  = $habito['racha_maxima'];
$total7       = completacionesEnPeriodo($pdo, $id_habito, $id_usuario, 7);
$total30      = completacionesEnPeriodo($pdo, $id_habito, $id_usuario, 30);
$pctSemana    = porcentajeSemanal($pdo, $id_habito, $id_usuario, $habito['meta_cantidad'] * 7);

$inicio_habito = strtotime($habito['fecha_inicio']);
$hoy_menos_13 = strtotime('-13 days');
$start_timestamp = max($inicio_habito, $hoy_menos_13);

$dias14 = [];
for ($i = 0; $i < 14; $i++) {
    $fecha = date('Y-m-d', strtotime("+$i days", $start_timestamp));
    $dias14[$fecha] = isset($historial[$fecha]) ? (int)$historial[$fecha] : 0;
}

$pageTitle = 'Historial: ' . limpiar($habito['nombre']) . ' | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    
    <div class="is-flex is-justify-content-space-between is-align-items-center mb-5">
      <div>
        <h1 class="title is-3" style="color: var(--secondary);">📋 Historial: <?php echo limpiar($habito['nombre']); ?></h1>
        <p class="subtitle is-6 mt-1">
          <span class="tag is-light is-info"><?php echo ucfirst(strtolower($habito['frequency_type'])); ?></span>
          <span class="tag is-light ml-2">Meta: <?php echo $habito['meta_cantidad']; ?> vez/período</span>
        </p>
      </div>
      <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-link is-light">← Mis hábitos</a>
    </div>

    <!-- Métricas -->
    <div class="columns is-multiline mb-5">
      <div class="column is-3">
        <div class="card has-text-centered h-100">
          <div class="card-content">
            <span class="is-size-1">🔥</span>
            <p class="title is-3 mt-2"><?php echo $rachaActual; ?></p>
            <p class="subtitle is-6">Racha actual</p>
          </div>
        </div>
      </div>
      <div class="column is-3">
        <div class="card has-text-centered h-100">
          <div class="card-content">
            <span class="is-size-1">🏆</span>
            <p class="title is-3 mt-2 has-text-warning"><?php echo $rachaMaxima; ?></p>
            <p class="subtitle is-6">Racha máxima</p>
          </div>
        </div>
      </div>
      <div class="column is-3">
        <div class="card has-text-centered h-100">
          <div class="card-content">
            <span class="is-size-1">📅</span>
            <p class="title is-3 mt-2 has-text-primary"><?php echo $total7; ?></p>
            <p class="subtitle is-6">Esta semana</p>
          </div>
        </div>
      </div>
      <div class="column is-3">
        <div class="card has-text-centered h-100">
          <div class="card-content">
            <span class="is-size-1">📆</span>
            <p class="title is-3 mt-2 has-text-link"><?php echo $total30; ?></p>
            <p class="subtitle is-6">Último mes</p>
          </div>
        </div>
      </div>
    </div>

    <div class="columns">
      <div class="column is-6">
        <!-- Progreso semanal -->
        <div class="card h-100">
          <div class="card-content">
            <div class="is-flex is-justify-content-space-between mb-2">
              <span class="title is-5 mb-0" style="color: var(--secondary);">Progreso Semanal</span>
              <strong style="color: var(--primary);"><?php echo $pctSemana; ?>%</strong>
            </div>
            <progress class="progress is-primary mb-3" value="<?php echo $pctSemana; ?>" max="100"><?php echo $pctSemana; ?>%</progress>
            
            <?php if ($pctSemana >= 100): ?>
              <p class="has-text-success has-text-weight-semibold">🎉 ¡Meta semanal cumplida!</p>
            <?php elseif ($pctSemana >= 50): ?>
              <p class="has-text-info">💪 Vas por buen camino esta semana.</p>
            <?php else: ?>
              <p class="has-text-grey">🌱 Aún hay tiempo para mejorar esta semana.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="column is-6">
        <!-- Insights -->
        <div class="card h-100">
          <div class="card-content">
            <?php
            // Solo contar los días desde que se creó el hábito hasta hoy
            $diasValidos = 0;
            $diasCumplidos = 0;
            $hoy = date('Y-m-d');
            foreach ($dias14 as $fecha => $veces) {
                if ($fecha >= $habito['fecha_inicio'] && $fecha <= $hoy) {
                    $diasValidos++;
                    if ($veces > 0) $diasCumplidos++;
                }
            }
            if ($diasValidos === 0) $diasValidos = 1; // evitar division por 0 si fecha inicio es futura
            $pct14 = round(($diasCumplidos / $diasValidos) * 100);
            ?>
            <p class="title is-5 mb-3" style="color: var(--secondary);">📊 Resumen de Rendimiento</p>
            <p class="mb-2">Completaste este hábito <strong><?php echo $diasCumplidos; ?> de los últimos <?php echo $diasValidos; ?> días</strong> activos (<?php echo $pct14; ?>%).</p>
            
            <?php if ($pct14 >= 80): ?>
              <div class="notification is-success is-light p-3">¡Excelente consistencia! Sigue así.</div>
            <?php elseif ($pct14 >= 50): ?>
              <div class="notification is-warning is-light p-3">Vas bien, pero hay margen de mejora.</div>
            <?php else: ?>
              <div class="notification is-danger is-light p-3">Intenta establecer un recordatorio para mejorar tu constancia.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Heatmap 14 Días -->
    <div class="card mt-4">
      <div class="card-content">
        <h2 class="title is-5 mb-4" style="color: var(--secondary);">Rendimiento Diario (Últimos 14 días)</h2>
        <div class="is-flex is-flex-wrap-wrap" style="gap: 15px;">
          <?php foreach ($dias14 as $fecha => $veces): ?>
            <?php 
              $esHoy = ($fecha === date('Y-m-d')); 
              $antesDeInicio = ($fecha < $habito['fecha_inicio']);
              $esFuturo = ($fecha > date('Y-m-d'));
            ?>
            <div class="has-text-centered" title="<?php echo $antesDeInicio ? 'Aún no creado' : ($esFuturo ? 'Próximamente' : ($fecha . ': ' . $veces . ' completacion(es)')); ?>" style="width: 50px; <?php echo $antesDeInicio ? 'opacity: 0.3;' : ''; ?>">
              <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 5px; <?php echo $esHoy ? 'font-weight: bold; color: var(--primary);' : ''; ?>">
                <?php echo date('d M', strtotime($fecha)); ?>
              </div>
              <div style="height: 50px; width: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; transition: all 0.2s; <?php 
                if ($antesDeInicio) {
                  echo 'background-color: transparent; border: 1px dashed #ccc;';
                } else if ($veces > 0 && !$esFuturo) {
                  echo 'background-color: var(--success); box-shadow: 0 4px 8px rgba(139, 195, 74, 0.3);';
                } else if ($esFuturo) {
                  echo 'background-color: transparent; border: 1px solid #eee;';
                } else {
                  echo 'background-color: var(--bg-light); border: 1px solid #e0e0e0;';
                }
              ?>">
                <?php if (!$antesDeInicio && !$esFuturo && $veces > 0) echo '<span style="color: white;" class="material-symbols-outlined">check</span>'; ?>
                <?php if ($antesDeInicio) echo '<span style="color: #ccc; font-size: 1rem;" class="material-symbols-outlined">block</span>'; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
