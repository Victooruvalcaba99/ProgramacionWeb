<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$id_habito  = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

// Cargar hábito actual
$stmt = $pdo->prepare("SELECT * FROM habitos WHERE id = :h AND id_usuario = :u");
$stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
$habito = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$habito) redirigir('/WebPageUpdate/habitos/home/habitos/index.php');
// Cargar metas disponibles
$stmtMetas = $pdo->prepare("SELECT id, titulo FROM metas WHERE id_usuario = :u AND completada = 0 ORDER BY titulo ASC");
$stmtMetas->execute([':u' => $id_usuario]);
$metas_disponibles = $stmtMetas->fetchAll(PDO::FETCH_ASSOC);
$mensaje = '';
$tipoMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? 'guardar';

    if ($accion === 'archivar') {
        $pdo->prepare("UPDATE habitos SET archivado = 1 WHERE id = :h AND id_usuario = :u")
            ->execute([':h' => $id_habito, ':u' => $id_usuario]);
        redirigir('/WebPageUpdate/habitos/home/habitos/index.php');
    }

    $nombre         = limpiar($_POST['nombre'] ?? '');
    $descripcion    = limpiar($_POST['descripcion'] ?? '');
    $frequency_type = in_array($_POST['frequency_type'] ?? '', ['DIARIO','SEMANAL','PERSONALIZADO'])
                      ? $_POST['frequency_type'] : 'DIARIO';
    $meta_cantidad  = max(1, (int)($_POST['meta_cantidad'] ?? 1));

    $params = null;
    if ($frequency_type === 'SEMANAL') {
        $dias   = array_map('intval', $_POST['dias_semana'] ?? [1,2,3,4,5]);
        $params = json_encode(['dias' => $dias]);
    } elseif ($frequency_type === 'PERSONALIZADO') {
        $cada_n = max(1, (int)($_POST['cada_n_dias'] ?? 2));
        $params = json_encode(['cada_n_dias' => $cada_n]);
    }

    if (empty($nombre)) {
        $mensaje = 'El nombre no puede estar vacío.';
        $tipoMsg = 'danger';
    } else {
        $frecCambio = $frequency_type !== $habito['frequency_type'];
        $id_meta = !empty($_POST['id_meta']) ? (int)$_POST['id_meta'] : null;

        $pdo->prepare(
            "UPDATE habitos
             SET nombre=:n, descripcion=:d, frequency_type=:ft,
                 frequency_params=:fp, meta_cantidad=:mc, id_meta=:im
             WHERE id=:h AND id_usuario=:u"
        )->execute([
            ':n'=>$nombre, ':d'=>$descripcion, ':ft'=>$frequency_type,
            ':fp'=>$params, ':mc'=>$meta_cantidad, ':im'=>$id_meta,
            ':h'=>$id_habito, ':u'=>$id_usuario,
        ]);

        if ($frecCambio) {
            $mensaje = '⚠️ Cambio guardado. La racha se recalculará con la nueva frecuencia.';
            $tipoMsg = 'warning';
        } else {
            redirigir('/WebPageUpdate/habitos/home/habitos/index.php');
        }
        $stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
        $habito = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$paramsActuales = json_decode($habito['frequency_params'] ?? '{}', true) ?: [];

$pageTitle = 'Editar Hábito | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="columns is-centered">
      <div class="column is-6">
        
        <div class="is-flex is-justify-content-space-between is-align-items-center mb-4">
            <h1 class="title is-3" style="color: var(--secondary);">✏️ Editar Hábito</h1>
            <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-light is-small">← Volver</a>
        </div>

        <?php if ($mensaje): ?>
          <div class="notification is-<?php echo $tipoMsg; ?> is-light"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <div class="notification is-info is-light">
          🔥 Racha actual: <strong><?php echo $habito['racha_actual']; ?> días</strong> &nbsp;|&nbsp;
          Racha máxima: <strong><?php echo $habito['racha_maxima']; ?> días</strong>
        </div>

        <div class="card">
            <div class="card-content">
                <form method="post" id="form-editar">
                  <input type="hidden" name="id" value="<?php echo $habito['id']; ?>">
                  <input type="hidden" name="accion" value="guardar" id="campo-accion">

                  <div class="field mb-4">
                    <label class="label">Nombre del hábito <span class="has-text-danger">*</span></label>
                    <div class="control">
                      <input class="input is-medium" type="text" name="nombre" value="<?php echo limpiar($habito['nombre']); ?>" required maxlength="100" autocomplete="off">
                    </div>
                  </div>

                  <div class="field mb-5">
                    <label class="label">Frecuencia <span class="has-text-danger">*</span></label>
                    <div class="tabs is-toggle is-fullwidth" id="freq-tabs">
                      <ul>
                        <li class="<?php echo $habito['frequency_type']==='DIARIO'?'is-active':''; ?>" data-freq="DIARIO">
                          <a><span>📅 Diario</span></a>
                        </li>
                        <li class="<?php echo $habito['frequency_type']==='SEMANAL'?'is-active':''; ?>" data-freq="SEMANAL">
                          <a><span>📆 Semanal</span></a>
                        </li>
                        <li class="<?php echo $habito['frequency_type']==='PERSONALIZADO'?'is-active':''; ?>" data-freq="PERSONALIZADO">
                          <a><span>⚙️ Personalizado</span></a>
                        </li>
                      </ul>
                    </div>
                    <input type="hidden" id="frequency_type" name="frequency_type" value="<?php echo $habito['frequency_type']; ?>">
                  </div>

                  <div id="panel-semanal" class="box is-shadowless has-background-light mb-4" style="display:<?php echo $habito['frequency_type']==='SEMANAL'?'block':'none'; ?>; border: 1px solid #eee;">
                    <label class="label">Días de la semana</label>
                    <div class="field is-grouped is-grouped-multiline">
                      <?php
                      $diasActivos = $paramsActuales['dias'] ?? [1,2,3,4,5];
                      $diasNombres = [1=>'Lun',2=>'Mar',3=>'Mié',4=>'Jue',5=>'Vie',6=>'Sáb',7=>'Dom'];
                      foreach ($diasNombres as $num => $nom):
                      ?>
                      <div class="control">
                        <label class="checkbox mr-2">
                          <input type="checkbox" name="dias_semana[]" value="<?php echo $num; ?>" <?php echo in_array($num,$diasActivos)?'checked':''; ?>>
                          <?php echo $nom; ?>
                        </label>
                      </div>
                      <?php endforeach; ?>
                    </div>
                  </div>

                  <div id="panel-personalizado" class="box is-shadowless has-background-light mb-4" style="display:<?php echo $habito['frequency_type']==='PERSONALIZADO'?'block':'none'; ?>; border: 1px solid #eee;">
                    <div class="field">
                        <label class="label">Cada cuántos días</label>
                        <div class="control">
                            <input class="input" type="number" name="cada_n_dias" min="1" max="30" value="<?php echo $paramsActuales['cada_n_dias'] ?? 2; ?>">
                        </div>
                    </div>
                  </div>

                  <div class="field mb-4">
                    <label class="label">Descripción</label>
                    <div class="control">
                      <textarea class="textarea has-fixed-size" name="descripcion" rows="2"><?php echo limpiar($habito['descripcion'] ?? ''); ?></textarea>
                    </div>
                  </div>

                  <div class="field mb-4">
                    <label class="label">Asignar a Meta (Opcional)</label>
                    <div class="control">
                      <div class="select is-fullwidth">
                        <select name="id_meta">
                          <option value="">🎯 General (Sin meta específica)</option>
                          <?php foreach ($metas_disponibles as $m): ?>
                            <option value="<?php echo $m['id']; ?>" <?php echo $habito['id_meta'] == $m['id'] ? 'selected' : ''; ?>>
                                <?php echo limpiar($m['titulo']); ?>
                            </option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="field mb-5">
                    <label class="label">Meta por período</label>
                    <div class="control">
                      <input class="input" type="number" name="meta_cantidad" min="1" max="31" value="<?php echo $habito['meta_cantidad']; ?>">
                    </div>
                  </div>

                  <div class="control">
                    <button type="submit" class="button is-primary is-medium is-fullwidth">
                        💾 Guardar Cambios
                    </button>
                  </div>
                </form>

                <hr style="margin: 1.5rem 0; background-color: #f0f0f0;">
                
                <form method="post" onsubmit="return confirm('¿Archivar este hábito? El historial se conservará pero el hábito ya no aparecerá en tu día a día.');">
                  <input type="hidden" name="id" value="<?php echo $habito['id']; ?>">
                  <input type="hidden" name="accion" value="archivar">
                  <button type="submit" class="button is-danger is-light is-fullwidth">
                      🗃️ Archivar Hábito
                  </button>
                </form>

            </div>
        </div>

      </div>
    </div>
  </div>
</section>

<script>
document.querySelectorAll('#freq-tabs li').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('#freq-tabs li').forEach(t => t.classList.remove('is-active'));
    tab.classList.add('is-active');
    
    const freq = tab.dataset.freq;
    document.getElementById('frequency_type').value = freq;
    
    document.getElementById('panel-semanal').style.display      = freq === 'SEMANAL'       ? 'block' : 'none';
    document.getElementById('panel-personalizado').style.display = freq === 'PERSONALIZADO' ? 'block' : 'none';
  });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
