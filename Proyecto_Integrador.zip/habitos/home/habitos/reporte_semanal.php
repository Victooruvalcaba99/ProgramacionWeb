<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];
$pageTitle = 'Reporte Semanal | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';

$stmt = $pdo->prepare("SELECT MIN(fecha_inicio) FROM habitos WHERE id_usuario = :u AND archivado = 0");
$stmt->execute([':u' => $id_usuario]);
$fecha_primer_habito = $stmt->fetchColumn() ?: date('Y-m-d');

$inicio_rango_date = max($fecha_primer_habito, date('Y-m-d', strtotime('-6 days')));
$inicio_rango = strtotime($inicio_rango_date);

$stmt = $pdo->prepare("
    SELECT h.id, h.fecha_inicio, m.fecha_limite AS meta_fecha_limite 
    FROM habitos h 
    LEFT JOIN metas m ON h.id_meta = m.id 
    WHERE h.id_usuario = :u AND h.archivado = 0
");
$stmt->execute([':u' => $id_usuario]);
$habitos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmtC = $pdo->prepare("SELECT id_habito, DATE(completado_en) as dia FROM completaciones WHERE id_usuario = :u AND anulado = 0");
$stmtC->execute([':u' => $id_usuario]);
$completaciones = $stmtC->fetchAll(PDO::FETCH_ASSOC);

$comps = [];
foreach ($completaciones as $c) {
    $comps[$c['id_habito']][$c['dia']] = true;
}

$planeados_semana = 0;
$completados_semana = 0;
$hoy = date('Y-m-d');

for ($i = 0; $i < 7; $i++) {
    $fecha = date('Y-m-d', strtotime("+$i days", $inicio_rango));
    foreach ($habitos as $h) {
        if ($fecha >= $h['fecha_inicio'] && $fecha <= $hoy) {
            $planeados_semana++;
            if (isset($comps[$h['id']][$fecha])) {
                $completados_semana++;
            }
        }
    }
}

if ($planeados_semana === 0) $planeados_semana = 1; // avoid division by zero
$consistency = round(($completados_semana / $planeados_semana) * 100);
$missed = max(0, $planeados_semana - $completados_semana);
?>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="is-flex is-justify-content-space-between is-align-items-center mb-5">
      <div>
        <h1 class="title is-3">📊 Reporte Semanal</h1>
        <p class="subtitle is-6">Resumen de tu constancia en los últimos 7 días</p>
      </div>
      <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="button is-link is-light">← Mis hábitos</a>
    </div>

    <?php if (empty($habitos)): ?>
      <div class="notification is-info is-light has-text-centered mb-5" style="padding: 3rem;">
          <span class="material-symbols-outlined mb-2" style="font-size: 4rem; color: var(--info);">auto_graph</span>
          <p class="title is-4">Aún no tienes hábitos activos</p>
          <p class="subtitle is-6 mt-2">Crea tu primer hábito para empezar a ver tus estadísticas y tendencias semanales.</p>
          <a href="/WebPageUpdate/habitos/home/habitos/crear.php" class="button is-primary mt-4">Crear mi primer hábito</a>
      </div>
    <?php else: ?>

      <div class="card mb-5">
        <div class="card-content">
          <p class="is-size-5 mb-3">Has completado <strong><?php echo $completados_semana; ?> de <?php echo $planeados_semana; ?> hábitos (<?php echo $consistency; ?>%)</strong> esta semana.</p>
          <progress class="progress <?php echo $consistency < 50 ? 'is-warning' : 'is-primary'; ?> is-medium" value="<?php echo $consistency; ?>" max="100"><?php echo $consistency; ?>%</progress>
        </div>
      </div>

      <div class="columns is-multiline mb-5">
        <div class="column is-4">
          <div class="card has-text-centered">
            <div class="card-content">
              <span class="is-size-1">✅</span>
              <p class="title is-3 mt-2"><?php echo $completados_semana; ?></p>
              <p class="subtitle is-6">Completados</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="card has-text-centered">
            <div class="card-content">
              <span class="is-size-1">❌</span>
              <p class="title is-3 mt-2 has-text-danger"><?php echo $missed; ?></p>
              <p class="subtitle is-6">Omitidos</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="card has-text-centered">
            <div class="card-content">
              <span class="is-size-1">📈</span>
              <p class="title is-3 mt-2 has-text-primary"><?php echo $consistency; ?>%</p>
              <p class="subtitle is-6">Consistencia</p>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-content">
          <h2 class="title is-4 mb-4">Tendencia Semanal</h2>
          <canvas id="weeklyChart" height="80"></canvas>
        </div>
      </div>

    <?php endif; ?>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const resp = await fetch('/WebPageUpdate/habitos/api/progress/weekly.php');
        const data = await resp.json();

        const ctx = document.getElementById('weeklyChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.dates,
                datasets: [
                    {
                        label: 'Completados',
                        data: data.completed,
                        backgroundColor: '#8BC34A', // Success
                        borderRadius: 6
                    },
                    {
                        label: 'Omitidos',
                        data: data.missed,
                        backgroundColor: '#FFA726', // Warning
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: { stacked: true, grid: { display: false } },
                    y: { stacked: true, beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: '#f0f0f0' } }
                },
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    } catch (e) {
        console.error('Error cargando gráfico:', e);
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
