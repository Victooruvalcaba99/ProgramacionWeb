<?php


require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método no permitido']);
    exit();
}

$body = json_decode(file_get_contents('php://input'), true);
$id_habito = (int) ($body['id_habito'] ?? 0);
$accion = $body['accion'] ?? '';
$id_usuario = (int) $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT id FROM habitos WHERE id = :h AND id_usuario = :u AND archivado = 0");
$stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Hábito no encontrado']);
    exit();
}

if ($accion === 'completar') {
    if (!habitoCompletadoHoy($pdo, $id_habito, $id_usuario)) {
        registrarCompletacion($pdo, $id_habito, $id_usuario);
    }
} elseif ($accion === 'anular') {
    anularCompletacionHoy($pdo, $id_habito, $id_usuario);
}

$racha = actualizarRacha($pdo, $id_habito, $id_usuario);

$stmtTotal = $pdo->prepare("SELECT COUNT(*) FROM habitos WHERE id_usuario = :u AND archivado = 0");
$stmtTotal->execute([':u' => $id_usuario]);
$total = (int) $stmtTotal->fetchColumn();

$stmtHechos = $pdo->prepare(
    "SELECT COUNT(DISTINCT c.id_habito) 
     FROM completaciones c
     JOIN habitos h ON c.id_habito = h.id
     WHERE c.id_usuario = :u 
       AND DATE(c.completado_en) = CURDATE() 
       AND c.anulado = 0
       AND h.archivado = 0"
);
$stmtHechos->execute([':u' => $id_usuario]);
$hechos = (int) $stmtHechos->fetchColumn();
$pctDia = $total > 0 ? (int) round(($hechos / $total) * 100) : 0;

$nuevasInsignias = [];
$gamificacion = null;

if ($accion === 'completar') {
    $nuevasInsignias = evaluarInsignias($pdo, $id_usuario);
    $gamificacion = sumarXP($pdo, $id_usuario, 10);
}


echo json_encode([
    'ok' => true,
    'racha' => $racha,
    'pct_dia' => $pctDia,
    'hechos' => $hechos,
    'total' => $total,
    'nuevas_insignias' => $nuevasInsignias,
    'gamificacion' => $gamificacion
]);
