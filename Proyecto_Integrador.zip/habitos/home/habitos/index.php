<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];

$stmt = $pdo->prepare("
    SELECT h.*, m.titulo AS meta_titulo, m.fecha_limite AS meta_fecha_limite 
    FROM habitos h 
    LEFT JOIN metas m ON h.id_meta = m.id 
    WHERE h.id_usuario = :u AND h.archivado = 0 
    ORDER BY h.creado_en ASC
");
$stmt->execute([':u' => $id_usuario]);
$todos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Datos para los últimos 7 días
$ultimos7dias = [];
for ($i = 6; $i >= 0; $i--) {
    $ultimos7dias[] = date('Y-m-d', strtotime("-$i days"));
}

$comps_7d = [];
$fecha_inicio_7d = $ultimos7dias[0];
$stmtC = $pdo->prepare("SELECT id_habito, DATE(completado_en) as dia FROM completaciones WHERE id_usuario = :u AND DATE(completado_en) >= :fi AND anulado = 0");
$stmtC->execute([':u' => $id_usuario, ':fi' => $fecha_inicio_7d]);
foreach ($stmtC->fetchAll(PDO::FETCH_ASSOC) as $c) {
    $comps_7d[$c['dia']][$c['id_habito']] = true;
}

$habitosAgrupados = [];
foreach ($todos as $h) {
    $m = $h['meta_titulo'] ? '🎯 ' . limpiar($h['meta_titulo']) : '📌 Hábitos Generales';
    $habitosAgrupados[$m][] = $h;
}

$habitosHoy = filtrarHabitosDeHoy($todos);
$totalHoy     = count($habitosHoy);
$completadosHoy = 0;
foreach ($habitosHoy as $hh) {
    if (isset($comps_7d[date('Y-m-d')][$hh['id']])) $completadosHoy++;
}
$pctDia       = $totalHoy > 0 ? round(($completadosHoy / $totalHoy) * 100) : 0;

$pageTitle = 'Mis Hábitos | HabitFlow';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/menu.php';
?>

<style>
.mini-tracker {
    display: flex;
    gap: 6px;
    margin-top: 8px;
}
.mini-day {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    font-weight: bold;
    color: white;
}
.mini-day.scheduled-pending {
    background-color: #ddd;
    color: #666;
}
.mini-day.scheduled-done {
    background-color: var(--success);
}
.mini-day.scheduled-missed {
    background-color: var(--warning);
}
.mini-day.unscheduled {
    background-color: transparent;
    border: 1px dashed #ccc;
    color: #ccc;
}
.meta-group-title {
    color: var(--secondary);
    border-bottom: 2px solid #eee;
    padding-bottom: 8px;
    margin-bottom: 15px;
    margin-top: 25px;
}
</style>

<section class="section" style="padding-top: 100px;">
    <div class="container">
        <div class="columns">
            
            <div class="column is-8">
                <div class="is-flex is-justify-content-space-between is-align-items-center mb-5">
                    <div>
                        <h1 class="title is-3">📅 Todos mis Hábitos</h1>
                        <p class="subtitle is-6">Agrupados por meta (Últimos 7 días)</p>
                    </div>
                    <a href="/WebPageUpdate/habitos/home/habitos/crear.php" class="button is-primary">+ Nuevo Hábito</a>
                </div>

                <!-- Pestañas de Vistas -->
                <div class="tabs is-toggle is-fullwidth mb-5">
                  <ul>
                    <li class="is-active" id="tab-btn-todos" onclick="cambiarVista('todos')">
                      <a><span class="material-symbols-outlined mr-2 is-size-6">view_list</span><span>Todos (7 días)</span></a>
                    </li>
                    <li id="tab-btn-pendientes" onclick="cambiarVista('pendientes')">
                      <a><span class="material-symbols-outlined mr-2 is-size-6">today</span><span>Por Cumplir Hoy</span></a>
                    </li>
                  </ul>
                </div>

                <?php if (empty($todos)): ?>
                    <div class="notification is-light has-text-centered">
                        <p>🌱 Aún no tienes ningún hábito registrado.</p>
                        <a href="/WebPageUpdate/habitos/home/habitos/crear.php" class="button is-primary mt-3">Crear mi primer hábito</a>
                    </div>
                <?php else: ?>
                    
                    <!-- VISTA: TODOS -->
                    <div id="vista-todos">
                        <div id="lista-habitos">
                        <?php foreach ($habitosAgrupados as $meta_nom => $habitos_de_meta): ?>
                            <h2 class="title is-5 meta-group-title"><?php echo $meta_nom; ?></h2>
                            
                            <?php foreach ($habitos_de_meta as $h): ?>
                                <?php
                                $toca_hoy = habitoEsParaFecha($h, date('Y-m-d'));
                                $hecho_hoy = isset($comps_7d[date('Y-m-d')][$h['id']]);
                                ?>
                                <div class="habit-list-item <?php echo $hecho_hoy ? 'is-completed' : ''; ?>" id="habito-<?php echo $h['id']; ?>" <?php echo !$toca_hoy ? 'style="opacity: 0.75;"' : ''; ?>>
                                    
                                    <div class="is-flex is-align-items-center" style="gap: 15px; flex-grow: 1;">
                                        
                                        <?php if ($toca_hoy): ?>
                                            <button class="button is-rounded is-success btn-completar <?php echo $hecho_hoy ? '' : 'is-outlined'; ?>"
                                                    data-id="<?php echo $h['id']; ?>"
                                                    data-hecho="<?php echo $hecho_hoy ? '1' : '0'; ?>"
                                                    title="<?php echo $hecho_hoy ? 'Desmarcar' : 'Marcar como hecho'; ?>">
                                                <span class="material-symbols-outlined check-icon"><?php echo $hecho_hoy ? 'check' : 'radio_button_unchecked'; ?></span>
                                            </button>
                                        <?php else: ?>
                                            <div style="width: 40px; height: 40px; border-radius: 50%; background: #f5f5f5; display: flex; align-items: center; justify-content: center;" title="No programado para hoy">
                                                <span class="material-symbols-outlined" style="color: #ccc; font-size: 18px;">bedtime</span>
                                            </div>
                                        <?php endif; ?>

                                        <div class="habit-info" style="flex-grow: 1;">
                                            <div class="is-flex is-justify-content-space-between is-align-items-center">
                                                <strong><?php echo limpiar($h['nombre']); ?></strong>
                                                <span class="badge-streak">🔥 <span class="racha-val"><?php echo $h['racha_actual']; ?></span> días</span>
                                            </div>
                                            
                                            <!-- Mini Tracker 7 Días -->
                                            <div class="mini-tracker">
                                                <?php 
                                                $nombres_dias = ['D','L','M','M','J','V','S'];
                                                foreach ($ultimos7dias as $idx => $f): 
                                                    $es_para_fecha = habitoEsParaFecha($h, $f);
                                                    $es_hecho = isset($comps_7d[$f][$h['id']]);
                                                    $es_hoy = ($f === date('Y-m-d'));
                                                    $num_dia = date('w', strtotime($f));
                                                    $letra = $nombres_dias[$num_dia];
                                                    
                                                    $clase = 'unscheduled';
                                                    if ($es_para_fecha) {
                                                        if ($es_hecho) {
                                                            $clase = 'scheduled-done';
                                                        } else if ($f < date('Y-m-d')) {
                                                            $clase = 'scheduled-missed';
                                                        } else {
                                                            $clase = 'scheduled-pending';
                                                            if ($es_hoy) $clase .= ' today-circle';
                                                        }
                                                    }
                                                ?>
                                                <div class="mini-day <?php echo $clase; ?>" title="<?php echo date('d M', strtotime($f)); ?>" id="circle-<?php echo $h['id']; ?>-<?php echo $f; ?>">
                                                    <?php echo $letra; ?>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="buttons is-align-self-start ml-3 mt-1">
                                        <a href="/WebPageUpdate/habitos/home/habitos/editar.php?id=<?php echo $h['id']; ?>" class="button is-small is-light" title="Editar">
                                            <span class="material-symbols-outlined is-size-6">edit</span>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- VISTA: PENDIENTES DE HOY -->
                    <div id="vista-pendientes" style="display: none;">
                        <div id="lista-pendientes">
                            <?php 
                            $hayPendientes = false;
                            foreach ($habitosHoy as $h): 
                                $hecho_hoy = isset($comps_7d[date('Y-m-d')][$h['id']]);
                                if ($hecho_hoy) continue;
                                $hayPendientes = true;
                            ?>
                            <div class="habit-list-item" id="habito-pend-<?php echo $h['id']; ?>">
                                <div class="is-flex is-align-items-center" style="gap: 15px; flex-grow: 1;">
                                    <button class="button is-rounded is-success is-outlined btn-completar"
                                            data-id="<?php echo $h['id']; ?>"
                                            data-hecho="0"
                                            title="Marcar como hecho">
                                        <span class="material-symbols-outlined check-icon">radio_button_unchecked</span>
                                    </button>
                                    <div class="habit-info">
                                        <strong><?php echo limpiar($h['nombre']); ?></strong>
                                        <div class="is-size-7 mt-1">
                                            <span class="tag is-rounded" style="font-size: 0.65rem; background-color: <?php echo colorParaHabito($h); ?>; color: #333;">
                                                🎯 <?php echo $h['meta_titulo'] ? limpiar($h['meta_titulo']) : 'General'; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            
                            <div id="msg-sin-pendientes" class="notification is-success is-light has-text-centered mt-4" style="display: <?php echo $hayPendientes ? 'none' : 'block'; ?>;">
                                ¡Felicidades! Has completado todos tus hábitos programados para hoy. 🎉
                            </div>
                        </div>
                    </div>

                <?php endif; ?>

            </div>

            <!-- Sidebar -->
            <div class="column is-4">
                <div class="card">
                    <div class="card-content">
                        <p class="title is-5 mb-2">Progreso Diario</p>
                        <p class="is-size-6 mb-3"><span id="comp-count"><?php echo $completadosHoy; ?></span> de <?php echo $totalHoy; ?> hábitos listos</p>
                        <progress id="main-progress" class="progress is-primary" value="<?php echo $pctDia; ?>" max="100"><?php echo $pctDia; ?>%</progress>
                    </div>
                </div>

                <?php 
                $insignias = obtenerInsignias($pdo, $id_usuario);
                if (!empty($insignias)): 
                ?>
                <div class="card mt-4">
                    <div class="card-content">
                        <p class="title is-5 mb-4">🏅 Mis Insignias</p>
                        <div class="is-flex is-flex-wrap-wrap" style="gap: 10px;">
                            <?php foreach ($insignias as $ins): ?>
                            <span class="tag is-medium is-light is-warning" title="<?php echo limpiar($ins['descripcion']); ?>">
                                <?php echo limpiar($ins['icono']); ?> <?php echo limpiar($ins['nombre']); ?>
                            </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</section>

<script>
function cambiarVista(vista) {
    document.getElementById('tab-btn-todos').classList.remove('is-active');
    document.getElementById('tab-btn-pendientes').classList.remove('is-active');
    document.getElementById('vista-todos').style.display = 'none';
    document.getElementById('vista-pendientes').style.display = 'none';
    
    document.getElementById('tab-btn-' + vista).classList.add('is-active');
    document.getElementById('vista-' + vista).style.display = 'block';
}

document.querySelectorAll('.btn-completar').forEach(btn => {
  btn.addEventListener('click', async function () {
    const id    = this.dataset.id;
    const hecho = this.dataset.hecho === '1';
    
    const itemTodos = document.getElementById('habito-' + id);
    const itemPend  = document.getElementById('habito-pend-' + id);
    
    const nuevoEstado = !hecho;
    
    // Update self dataset
    this.dataset.hecho = nuevoEstado ? '1' : '0';
    
    // 1. Sync Vista Todos
    if (itemTodos) {
        const btnTodos = itemTodos.querySelector('.btn-completar');
        if (btnTodos) {
            btnTodos.dataset.hecho = nuevoEstado ? '1' : '0';
            btnTodos.classList.toggle('is-outlined', !nuevoEstado);
            btnTodos.querySelector('.check-icon').textContent = nuevoEstado ? 'check' : 'radio_button_unchecked';
        }
        itemTodos.classList.toggle('is-completed', nuevoEstado);
        
        // Update mini-tracker if it exists
        const todayCircle = itemTodos.querySelector('.today-circle');
        if (todayCircle) {
            if (nuevoEstado) {
                todayCircle.classList.remove('scheduled-pending');
                todayCircle.classList.add('scheduled-done');
            } else {
                todayCircle.classList.remove('scheduled-done');
                todayCircle.classList.add('scheduled-pending');
            }
        }
        
        if (nuevoEstado) {
            itemTodos.classList.add('animate-pop');
            setTimeout(() => itemTodos.classList.remove('animate-pop'), 300);
        }
    }
    
    // 2. Sync Vista Pendientes (Disappear on complete, appear on undo)
    if (itemPend) {
        if (nuevoEstado) {
            itemPend.style.display = 'none'; // Hide if done
        } else {
            itemPend.style.display = 'block'; // Show if undone
            const btnPend = itemPend.querySelector('.btn-completar');
            if (btnPend) {
                btnPend.dataset.hecho = '0';
            }
        }
        
        // Check if all are done to show success message
        const pendientesRestantes = document.querySelectorAll('#lista-pendientes .habit-list-item[style="display: block;"], #lista-pendientes .habit-list-item:not([style*="display: none"])');
        document.getElementById('msg-sin-pendientes').style.display = pendientesRestantes.length === 0 ? 'block' : 'none';
    }

    try {
      const resp = await fetch('/WebPageUpdate/habitos/home/habitos/completar.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id_habito: id, accion: nuevoEstado ? 'completar' : 'anular' })
      });
      const data = await resp.json();

      if (data.racha !== undefined && itemTodos) {
        const rVal = itemTodos.querySelector('.racha-val');
        if (rVal) rVal.textContent = data.racha;
      }

      // ACTUALIZACIÓN DE GAMIFICACIÓN
      if (data.gamificacion) {
          const g = data.gamificacion;
          const navLevel = document.getElementById('nav-user-level');
          const navXpBar = document.getElementById('nav-xp-bar');
          const navXpVal = document.getElementById('nav-xp-val');
          
          if (navLevel) navLevel.textContent = 'Nivel ' + g.nivel;
          if (navXpBar) {
              navXpBar.value = g.xp_actual;
              navXpBar.max = g.xp_objetivo;
          }
          if (navXpVal) navXpVal.textContent = g.xp_actual;
          
          if (g.subio_nivel) {
              // Animación simple de Level Up
              alert('🎉 ¡FELICIDADES! Has subido al Nivel ' + g.nivel + '. Sigue así.');
          }
      }
      
      // Update progress bar if backend sends it

      if (data.progresoDia !== undefined) {
          const compCount = document.getElementById('comp-count');
          const pBar = document.getElementById('main-progress');
          if (compCount) compCount.textContent = data.completadosHoy;
          if (pBar) {
              pBar.value = data.progresoDia;
              pBar.textContent = data.progresoDia + '%';
          }
      }

    } catch (error) {
      console.error(error);
      alert('Error de conexión. Tus cambios podrían no haberse guardado.');
    }
  });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
