<?php
require_once __DIR__ . '/../includes/verificar_sesion.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/conexion.php';

$id_usuario = (int)$_SESSION['usuario_id'];

// Establecer zona horaria si es necesario
date_default_timezone_set('America/Mexico_City');

// Obtener año y mes (YYYY-MM)
if (isset($_GET['ym'])) {
    $ym = $_GET['ym'];
} else {
    $ym = date('Y-m');
}

$timestamp = strtotime($ym . '-01');
if ($timestamp === false) {
    $ym = date('Y-m');
    $timestamp = strtotime($ym . '-01');
}

$hoy = date('Y-m-d');
$html_title = date('F Y', $timestamp);
// Traducir meses
$meses = ['January'=>'Enero', 'February'=>'Febrero', 'March'=>'Marzo', 'April'=>'Abril', 'May'=>'Mayo', 'June'=>'Junio', 'July'=>'Julio', 'August'=>'Agosto', 'September'=>'Septiembre', 'October'=>'Octubre', 'November'=>'Noviembre', 'December'=>'Diciembre'];
$html_title = strtr($html_title, $meses);

$prev = date('Y-m', mktime(0, 0, 0, date('m', $timestamp) - 1, 1, date('Y', $timestamp)));
$next = date('Y-m', mktime(0, 0, 0, date('m', $timestamp) + 1, 1, date('Y', $timestamp)));

$day_count = date('t', $timestamp);
$str = date('w', $timestamp); // 0 (Sun) to 6 (Sat)
// Convert to Monday=1, Sunday=7 for standard calendar or keep Sunday=0
// Let's make Monday = 1
$str = $str == 0 ? 7 : $str;

// Get habits
$stmt = $pdo->prepare("
    SELECT h.*, m.fecha_limite AS meta_fecha_limite 
    FROM habitos h 
    LEFT JOIN metas m ON h.id_meta = m.id 
    WHERE h.id_usuario = :u AND h.archivado = 0 
    ORDER BY h.creado_en ASC
");
$stmt->execute([':u' => $id_usuario]);
$habitos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get completaciones in this month
$start_date = $ym . '-01';
$end_date   = $ym . '-' . $day_count;
$stmtC = $pdo->prepare("SELECT id_habito, DATE(completado_en) as dia FROM completaciones WHERE id_usuario = :u AND DATE(completado_en) BETWEEN :s AND :e AND anulado = 0");
$stmtC->execute([':u' => $id_usuario, ':s' => $start_date, ':e' => $end_date]);
$comps_raw = $stmtC->fetchAll(PDO::FETCH_ASSOC);

// Get agenda in this month
$stmtA = $pdo->prepare("SELECT id_habito, fecha, hora FROM agenda_diaria WHERE id_usuario = :u AND fecha BETWEEN :s AND :e");
$stmtA->execute([':u' => $id_usuario, ':s' => $start_date, ':e' => $end_date]);
$agenda_raw = $stmtA->fetchAll(PDO::FETCH_ASSOC);
$agenda = [];
foreach ($agenda_raw as $a) {
    $agenda[$a['fecha']][$a['id_habito']] = $a['hora'];
}

$diasData = [];
for ($day = 1; $day <= $day_count; $day++) {
    $fecha = $ym . '-' . str_pad($day, 2, "0", STR_PAD_LEFT);
    $diasData[$fecha] = [];
    foreach ($habitos as $h) {
        if (habitoEsParaFecha($h, $fecha)) {
            $h['completado'] = isset($comps[$fecha][$h['id']]);
            $h['hora'] = isset($agenda[$fecha][$h['id']]) ? (int)$agenda[$fecha][$h['id']] : null;
            $h['color'] = colorParaHabito($h);
            $diasData[$fecha][] = $h;
        }
    }
}

$pageTitle = 'Calendario | HabitFlow';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/menu.php';
?>

<style>
.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 8px;
    margin-bottom: 20px;
}
.calendar-header {
    text-align: center;
    font-weight: bold;
    padding: 10px;
    background: var(--light);
    border-radius: 8px;
    color: var(--text-muted);
}
.calendar-day {
    min-height: 120px;
    background: #fff;
    border: 1px solid #eee;
    border-radius: 12px;
    padding: 10px;
    display: flex;
    flex-direction: column;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
    transition: transform 0.2s;
}
.calendar-day:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.05);
}
.calendar-day.empty {
    background: transparent;
    border: none;
    box-shadow: none;
}
.calendar-day.today {
    border: 2px solid var(--primary);
    background: #fdfdfd;
}
.day-number {
    font-weight: bold;
    color: var(--secondary);
    margin-bottom: 8px;
    font-size: 1.1rem;
}
.habit-badge {
    font-size: 0.7rem;
    padding: 4px 6px;
    border-radius: 4px;
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: flex;
    align-items: center;
    border-left: 3px solid transparent;
}
.habit-badge.pending {
    background: var(--bg-light);
    color: var(--text-muted);
    border-left-color: #ddd;
}
.habit-badge.completed {
    background: var(--success-light, #f1f8e9);
    color: var(--success-dark, #33691e);
    border-left-color: var(--success);
}
.habit-badge.missed {
    background: #fff3e0;
    color: #e65100;
    border-left-color: var(--warning);
}
.habit-badge .material-symbols-outlined {
    font-size: 14px;
    margin-right: 4px;
}
</style>

<section class="section" style="padding-top: 100px;">
  <div class="container">
    <div class="is-flex is-justify-content-space-between is-align-items-center mb-5">
      <div>
        <h1 class="title is-3" style="color: var(--secondary);">🗓️ Calendario de Hábitos</h1>
        <p class="subtitle is-6">Visualiza tu rutina mensual completa.</p>
      </div>
      <div>
        <a href="?ym=<?php echo $prev; ?>" class="button is-light">&laquo; Anterior</a>
        <strong class="mx-3 is-size-5"><?php echo $html_title; ?></strong>
        <a href="?ym=<?php echo $next; ?>" class="button is-light">Siguiente &raquo;</a>
      </div>
    </div>

    <div class="card">
        <div class="card-content" style="background-color: #fcfcfc;">
            <div class="calendar-grid">
                <div class="calendar-header">Lun</div>
                <div class="calendar-header">Mar</div>
                <div class="calendar-header">Mié</div>
                <div class="calendar-header">Jue</div>
                <div class="calendar-header">Vie</div>
                <div class="calendar-header">Sáb</div>
                <div class="calendar-header">Dom</div>
                
                <?php
                // Espacios vacíos antes del primer día
                for ($i = 1; $i < $str; $i++) {
                    echo '<div class="calendar-day empty"></div>';
                }

                for ($day = 1; $day <= $day_count; $day++) {
                    $fecha = $ym . '-' . str_pad($day, 2, "0", STR_PAD_LEFT);
                    $esHoy = ($fecha === $hoy);
                    $habitos_dia = $diasData[$fecha] ?? [];
                    $scheduled_count = count($habitos_dia);
                    
                    echo '<div class="calendar-day ' . ($esHoy ? 'today' : '') . '" style="cursor:pointer;" onclick="abrirAgenda(\'' . $fecha . '\')">';
                    echo '<div class="day-number">' . $day . '</div>';
                    
                    if ($scheduled_count > 0) {
                        $h = $habitos_dia[0];
                        $completado = $h['completado'];
                        $pasado = ($fecha < $hoy);
                        
                        $icon = $completado ? 'check_circle' : ($pasado ? 'cancel' : 'schedule');
                        $opacity = $completado ? '1' : ($pasado ? '0.7' : '0.9');
                        
                        echo '<div class="habit-badge" style="background-color: ' . $h['color'] . '; color: #333; opacity: ' . $opacity . ';" title="' . limpiar($h['nombre']) . '">';
                        echo '<span class="material-symbols-outlined">' . $icon . '</span>';
                        echo limpiar($h['nombre']);
                        echo '</div>';
                        
                        if ($scheduled_count > 1) {
                            $mas = $scheduled_count - 1;
                            echo '<div class="habit-badge" style="background-color: #f0f0f0; color: #666; justify-content: center;">';
                            echo '<span class="material-symbols-outlined" style="font-size: 16px;">add</span> ' . $mas . ' más';
                            echo '</div>';
                        }
                    }

                    echo '</div>';
                }

                // Completar la última fila
                $total_cells = ($str - 1) + $day_count;
                $remaining = 7 - ($total_cells % 7);
                if ($remaining < 7) {
                    for ($i = 0; $i < $remaining; $i++) {
                        echo '<div class="calendar-day empty"></div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>

  </div>
</section>

<!-- Agenda Modal -->
<div id="agenda-modal" class="modal">
  <div class="modal-background" onclick="cerrarAgenda()"></div>
  <div class="modal-card" style="width: 90%; max-width: 800px;">
    <header class="modal-card-head">
      <p class="modal-card-title" id="agenda-title">Agenda del Día</p>
      <button class="delete" aria-label="close" onclick="cerrarAgenda()"></button>
    </header>
    <section class="modal-card-body">
      <div class="columns">
        <div class="column is-4">
            <h3 class="subtitle is-6 mb-2"><strong>Hábitos sin hora asignada</strong></h3>
            <p class="is-size-7 has-text-grey mb-3">Arrastra un hábito al horario deseado</p>
            <div id="unassigned-habits" class="box" style="min-height: 300px; background-color: #f9f9f9; padding: 10px;" ondrop="drop(event, -1)" ondragover="allowDrop(event)">
                <!-- Unassigned habits go here -->
            </div>
        </div>
        <div class="column is-8">
            <h3 class="subtitle is-6 mb-2"><strong>Agenda por hora</strong></h3>
            <div id="hourly-schedule" class="box" style="height: 60vh; overflow-y: auto; padding: 0;">
                <?php for($h=0; $h<24; $h++): ?>
                <div class="is-flex" style="border-bottom: 1px solid #eee;">
                    <div style="width: 60px; text-align: right; padding: 10px; color: var(--text-muted); font-size: 0.85rem; border-right: 1px solid #eee;">
                        <?php echo str_pad($h, 2, "0", STR_PAD_LEFT); ?>:00
                    </div>
                    <div class="hour-slot" id="hour-<?php echo $h; ?>" style="flex-grow: 1; min-height: 40px; padding: 5px;" ondrop="drop(event, <?php echo $h; ?>)" ondragover="allowDrop(event)">
                        <!-- Dropped habits go here -->
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
      </div>
    </section>
  </div>
</div>

<style>
.draggable-habit {
    padding: 8px 12px;
    margin-bottom: 8px;
    border-radius: 6px;
    cursor: grab;
    font-size: 0.9rem;
    font-weight: 500;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    color: #333;
    display: flex;
    align-items: center;
}
.draggable-habit .material-symbols-outlined {
    font-size: 16px;
    margin-right: 6px;
}
.hour-slot.drag-over {
    background-color: #f0f8ff;
}
</style>

<script>
const diasData = <?php echo json_encode($diasData); ?>;
let currentDate = null;

function formatDate(dateStr) {
    const parts = dateStr.split('-');
    const date = new Date(parts[0], parts[1]-1, parts[2]);
    return date.toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function abrirAgenda(fecha) {
    currentDate = fecha;
    document.getElementById('agenda-title').innerText = "Agenda: " + formatDate(fecha);
    
    // Clear slots
    document.getElementById('unassigned-habits').innerHTML = '';
    for(let h=0; h<24; h++) {
        document.getElementById('hour-'+h).innerHTML = '';
    }
    
    const habits = diasData[fecha] || [];
    
    habits.forEach(habit => {
        const div = document.createElement('div');
        div.className = 'draggable-habit';
        div.draggable = true;
        div.id = 'drag-' + habit.id;
        div.dataset.id = habit.id;
        div.style.backgroundColor = habit.color;
        
        const icon = habit.completado ? 'check_circle' : 'drag_indicator';
        div.innerHTML = `<span class="material-symbols-outlined">${icon}</span> ${habit.nombre}`;
        
        div.ondragstart = function(ev) {
            ev.dataTransfer.setData("text", ev.target.id);
        };
        
        if (habit.hora !== null && habit.hora >= 0 && habit.hora < 24) {
            document.getElementById('hour-' + habit.hora).appendChild(div);
        } else {
            document.getElementById('unassigned-habits').appendChild(div);
        }
    });
    
    document.getElementById('agenda-modal').classList.add('is-active');
}

function cerrarAgenda() {
    document.getElementById('agenda-modal').classList.remove('is-active');
}

function allowDrop(ev) {
    ev.preventDefault();
}

async function drop(ev, hour) {
    ev.preventDefault();
    const data = ev.dataTransfer.getData("text");
    const draggedEl = document.getElementById(data);
    const habitId = draggedEl.dataset.id;
    
    // Find closest valid drop container
    let dropTarget = ev.target;
    while(dropTarget && !dropTarget.id.startsWith('hour-') && dropTarget.id !== 'unassigned-habits') {
        dropTarget = dropTarget.parentNode;
    }
    
    if (dropTarget) {
        dropTarget.appendChild(draggedEl);
        
        // Update frontend state
        const habitObj = diasData[currentDate].find(h => h.id == habitId);
        if (habitObj) {
            habitObj.hora = hour >= 0 ? hour : null;
        }
        
        // Save to backend
        try {
            await fetch('/WebPageUpdate/habitos/api/agenda/update.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_habito: habitId,
                    fecha: currentDate,
                    hora: hour >= 0 ? hour : -1
                })
            });
        } catch (e) {
            console.error("Failed to save agenda", e);
        }
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
