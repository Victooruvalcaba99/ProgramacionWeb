<?php
session_start();
session_unset();
session_destroy();
header('Location: /WebPageUpdate/habitos/index.php');
exit();
