<?php
session_start();

if (isset($_SESSION['usuario'])) {
    header('Location: /WebPageUpdate/habitos/home/index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión | HabitFlow</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
    <link rel="stylesheet" href="/WebPageUpdate/habitos/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
</head>
<body style="background-color: var(--bg-light);">

    <nav class="navbar" style="background-color: transparent;">
        <div class="container">
            <div class="navbar-brand">
                <a class="navbar-item" style="color: var(--primary); font-weight: 700; font-size: 1.5rem;" href="/WebPageUpdate/habitos/index.php">
                    HabitFlow
                </a>
            </div>
            <div class="navbar-menu is-active">
                <div class="navbar-end">
                    <a href="/WebPageUpdate/habitos/index.php" class="navbar-item">Inicio</a>
                    <a href="/WebPageUpdate/habitos/index.php#quienes-somos" class="navbar-item">Quiénes Somos</a>
                    <div class="navbar-item">
                        <a href="/WebPageUpdate/habitos/registro.php" class="button is-primary is-outlined">Crear Usuario</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <section class="section" style="display: flex; align-items: center; justify-content: center; min-height: 80vh;">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-4">
                    <div class="has-text-centered mb-5">
                        <h1 class="title is-3" style="color: var(--secondary);">Iniciar Sesión</h1>
                        <p class="subtitle is-6">Bienvenida de nuevo</p>
                    </div>
                    
                    <div class="card" style="padding: 2rem;">
                        <div class="card-content p-0">
                            <?php if (isset($_GET['error'])): ?>
                                <div class="notification is-danger is-light">
                                    Usuario o contraseña incorrectos.
                                </div>
                            <?php endif; ?>

                            <form action="/WebPageUpdate/habitos/login.php" method="post">
                                <div class="field">
                                    <label class="label">Usuario</label>
                                    <div class="control has-icons-left">
                                        <input class="input" type="text" name="usuario" placeholder="Ej. Ana" required>
                                        <span class="icon is-small is-left">
                                            <span class="material-symbols-outlined">person</span>
                                        </span>
                                    </div>
                                </div>

                                <div class="field">
                                    <label class="label">Contraseña</label>
                                    <div class="control has-icons-left">
                                        <input class="input" type="password" name="password" placeholder="••••••••" required>
                                        <span class="icon is-small is-left">
                                            <span class="material-symbols-outlined">lock</span>
                                        </span>
                                    </div>
                                </div>

                                <div class="field mt-5">
                                    <div class="control">
                                        <button class="button is-primary is-fullwidth" type="submit">Entrar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
