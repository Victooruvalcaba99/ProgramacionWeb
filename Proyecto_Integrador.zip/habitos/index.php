<?php
session_start();

if (isset($_SESSION['usuario'])) {
    header('Location: /WebPageUpdate/habitos/home/index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HabitFlow | Transforma tu Vida</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
    <link rel="stylesheet" href="/WebPageUpdate/habitos/assets/css/style.css">
    <style>
      html { scroll-behavior: smooth; }
    </style>
</head>
<body>
    <section class="hero is-fullheight" style="background-color: var(--bg-light);">
        <div class="hero-head">
            <nav class="navbar is-fixed-top" style="background-color: var(--bg-white);">
                <div class="container">
                    <div class="navbar-brand">
                        <a class="navbar-item" style="color: var(--primary); font-weight: 700; font-size: 1.5rem;" href="/WebPageUpdate/habitos/index.php">
                            HabitFlow
                        </a>
                        <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarHome">
                            <span aria-hidden="true"></span>
                            <span aria-hidden="true"></span>
                            <span aria-hidden="true"></span>
                        </a>
                    </div>
                    <div id="navbarHome" class="navbar-menu">
                        <div class="navbar-end">
                            <a href="/WebPageUpdate/habitos/index.php" class="navbar-item">Inicio</a>
                            <a href="#quienes-somos" class="navbar-item">Quiénes Somos</a>
                            <a href="/WebPageUpdate/habitos/registro.php" class="navbar-item">Crear Usuario</a>
                            <div class="navbar-item">
                                <a href="/WebPageUpdate/habitos/iniciar_sesion.php" class="button is-primary is-outlined">
                                    Iniciar Sesión
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>

        <div class="hero-body">
            <div class="container has-text-centered">
                <div class="columns is-vcentered is-centered">
                    <div class="column is-6">
                        <h1 class="title is-1" style="color: var(--secondary); font-weight: 700;">
                            Construye mejores hábitos, paso a paso.
                        </h1>
                        <h2 class="subtitle is-4" style="color: var(--text-muted); margin-top: 20px;">
                            Una plataforma diseñada para ayudarte a alcanzar tus metas diarias con motivación y claridad.
                        </h2>
                        <br>
                        <div class="buttons is-centered">
                            <a href="/WebPageUpdate/habitos/registro.php" class="button is-primary is-large is-rounded">
                                <strong>Comenzar Ahora</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="quienes-somos" class="section is-medium" style="background-color: var(--bg-white);">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-8 has-text-centered">
                    <h2 class="title is-2" style="color: var(--secondary);">Quiénes Somos</h2>
                    <p class="subtitle is-5" style="color: var(--text-muted); margin-top: 20px; line-height: 1.8;">
                        En HabitFlow, creemos que los grandes cambios comienzan con pequeñas acciones consistentes. 
                        Somos un equipo apasionado por la productividad y el bienestar, dedicados a construir herramientas 
                        que te empoderen a tomar el control de tu día a día de una forma sencilla, amigable y libre de estrés.
                        Nuestro enfoque se basa en principios científicos de formación de hábitos y diseño centrado en la tranquilidad.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
      const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
      if ($navbarBurgers.length > 0) {
        $navbarBurgers.forEach( el => {
          el.addEventListener('click', () => {
            const target = el.dataset.target;
            const $target = document.getElementById(target);
            el.classList.toggle('is-active');
            $target.classList.toggle('is-active');
          });
        });
      }
    });
    </script>
</body>
</html>
