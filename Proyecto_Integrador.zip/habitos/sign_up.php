<?php
// sign_up.php  —  registro de nuevos usuarios
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro | LexEconomica</title>
    <link rel="stylesheet" href="/WebPageUpdate/habitos/assets/css/style.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-container">
            <div class="card-header">
                <h1>Crear Cuenta</h1>
                <p>Regístrate para acceder a la plataforma.</p>
            </div>
            <form action="/WebPageUpdate/habitos/sign_up.php" method="post" novalidate>
                <div class="form-group">
                    <label for="nombre">Nombre completo</label>
                    <div class="input-wrapper">
                        <input type="text" name="nombre" id="nombre" placeholder="Tu nombre" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="usuario">Usuario</label>
                    <div class="input-wrapper">
                        <input type="text" name="usuario" id="usuario" placeholder="Elige un usuario" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <div class="input-wrapper">
                        <input type="password" name="password" id="password" placeholder="••••••••" required>
                    </div>
                </div>
                <input type="submit" value="Registrarse →">
            </form>
            <p style="text-align:center;margin-top:20px;">
                <a href="/WebPageUpdate/habitos/index.php" style="color:#818cf8;">← Ya tengo cuenta</a>
            </p>
        </div>
    </div>
</body>
</html>
