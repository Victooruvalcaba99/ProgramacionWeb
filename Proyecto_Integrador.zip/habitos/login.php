<?php
session_start();
require_once __DIR__ . '/includes/conexion.php';

$usuario  = $_POST['usuario']  ?? '';
$password = $_POST['password'] ?? '';

$sql  = "SELECT id, usuario, password, nombre, id_rol FROM usuarios WHERE usuario = :usuario LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':usuario', $usuario);
$stmt->execute();

$datosUsuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($datosUsuario && password_verify($password, $datosUsuario['password'])) {
    $_SESSION['usuario_id'] = $datosUsuario['id'];
    $_SESSION['nombre']     = $datosUsuario['nombre'];
    $_SESSION['usuario']    = $datosUsuario['usuario'];
    $_SESSION['id_rol']     = $datosUsuario['id_rol'];

    header('Location: /WebPageUpdate/habitos/home/index.php');
} else {
    header('Location: /WebPageUpdate/habitos/iniciar_sesion.php?error=1');
}
exit();
