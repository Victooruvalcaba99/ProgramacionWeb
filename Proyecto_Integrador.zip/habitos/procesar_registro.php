<?php
session_start();
require_once __DIR__ . '/includes/conexion.php';

$nombre   = $_POST['nombre']   ?? '';
$usuario  = $_POST['usuario']  ?? '';
$password = $_POST['password'] ?? '';

if(empty($nombre) || empty($usuario) || empty($password)){
    header('Location: /WebPageUpdate/habitos/registro.php?error=1');
    exit();
}

// Comprobar si el usuario ya existe
$stmt = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = :u LIMIT 1");
$stmt->execute([':u' => $usuario]);
if($stmt->fetch()){
    header('Location: /WebPageUpdate/habitos/registro.php?error=userexiste');
    exit();
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO usuarios (nombre, usuario, password, id_rol) VALUES (:n, :u, :p, 2)");
$stmt->execute([
    ':n' => $nombre,
    ':u' => $usuario,
    ':p' => $hash
]);

$new_id = $pdo->lastInsertId();

$_SESSION['usuario_id'] = $new_id;
$_SESSION['nombre']     = $nombre;
$_SESSION['usuario']    = $usuario;
$_SESSION['id_rol']     = 2;

header('Location: /WebPageUpdate/habitos/home/index.php');
exit();
