    <footer class="footer mt-6" style="background-color: var(--bg-light); padding: 2rem 1.5rem;">
        <div class="content has-text-centered">
            <p>&copy; <?php echo date('Y'); ?> <strong>HabitFlow</strong>. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>
