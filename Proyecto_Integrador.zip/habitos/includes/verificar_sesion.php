<?php
/**
 * verificar_sesion.php
 * Incluir al inicio de cada página protegida.
 * Redirige al login si no hay sesión activa.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario'])) {
    header('Location: /WebPageUpdate/habitos/login.php');
    exit();
}
