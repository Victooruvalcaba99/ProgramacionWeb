<?php
date_default_timezone_set('America/Mexico_City');

// ==========================================
// CONFIGURACIÓN DE BASE DE DATOS PARA AWARDSPACE
// ==========================================
// Credenciales actualizadas para AwardSpace
$host     = "fdb1034.awardspace.net";
$dbname   = "4736459_loginhf";
$user     = "4736459_loginhf";
$password = ".OrangeFox99";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pdo->exec("SET time_zone = '-06:00'");

} catch (PDOException $e) {
    die("Error de conexion: " . $e->getMessage());
}
