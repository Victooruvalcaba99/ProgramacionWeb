<?php



function limpiar(string $dato): string
{
    return htmlspecialchars(strip_tags(trim($dato)), ENT_QUOTES, 'UTF-8');
}


function colorParaHabito(array $habito): string
{
    $id = !empty($habito['id_meta']) ? 'm_' . $habito['id_meta'] : 'h_' . $habito['id'];
    $hash = md5($id);
    $hue = hexdec(substr($hash, 0, 4)) % 360;
    return "hsl($hue, 70%, 85%)";
}

/**
 * Redirige a una URL y detiene la ejecución.
 */
function redirigir(string $url): void
{
    header("Location: $url");
    exit();
}


function esAdmin(): bool
{
    return isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 1;
}



function habitoCompletadoHoy(PDO $pdo, int $id_habito, int $id_usuario): bool
{
    $hoy = date('Y-m-d');
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM completaciones
         WHERE id_habito = :h AND id_usuario = :u
           AND DATE(completado_en) = :hoy AND anulado = 0"
    );
    $stmt->execute([':h' => $id_habito, ':u' => $id_usuario, ':hoy' => $hoy]);
    return $stmt->fetchColumn() > 0;
}


function registrarCompletacion(PDO $pdo, int $id_habito, int $id_usuario): int
{
    $stmt = $pdo->prepare(
        "INSERT INTO completaciones (id_habito, id_usuario, completado_en)
         VALUES (:h, :u, NOW())"
    );
    $stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
    return (int) $pdo->lastInsertId();
}


function anularCompletacionHoy(PDO $pdo, int $id_habito, int $id_usuario): void
{
    $hoy = date('Y-m-d');
    $pdo->prepare(
        "UPDATE completaciones SET anulado = 1
         WHERE id_habito = :h AND id_usuario = :u
           AND DATE(completado_en) = :hoy AND anulado = 0
         ORDER BY completado_en DESC LIMIT 1"
    )->execute([':h' => $id_habito, ':u' => $id_usuario, ':hoy' => $hoy]);
}


function completacionesEnPeriodo(PDO $pdo, int $id_habito, int $id_usuario, int $dias = 7): int
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM completaciones
         WHERE id_habito = :h AND id_usuario = :u
           AND completado_en >= DATE_SUB(NOW(), INTERVAL :dias DAY)
           AND anulado = 0"
    );
    $stmt->execute([':h' => $id_habito, ':u' => $id_usuario, ':dias' => $dias]);
    return (int) $stmt->fetchColumn();
}


function porcentajeSemanal(PDO $pdo, int $id_habito, int $id_usuario, int $meta): float
{
    $completadas = completacionesEnPeriodo($pdo, $id_habito, $id_usuario, 7);
    if ($meta <= 0)
        return 0.0;
    return min(100.0, round(($completadas / $meta) * 100, 1));
}


function calcularRachaActual(PDO $pdo, int $id_habito, int $id_usuario): int
{
    // Obtiene días distintos con completaciones, ordenados desc
    $stmt = $pdo->prepare(
        "SELECT DISTINCT DATE(completado_en) AS dia
         FROM completaciones
         WHERE id_habito = :h AND id_usuario = :u AND anulado = 0
         ORDER BY dia DESC"
    );
    $stmt->execute([':h' => $id_habito, ':u' => $id_usuario]);
    $dias = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (empty($dias))
        return 0;

    $racha = 0;
    $esperado = new DateTime('today');

    if ($dias[0] !== $esperado->format('Y-m-d')) {
        $esperado->modify('-1 day');
        if ($dias[0] !== $esperado->format('Y-m-d'))
            return 0;
    }

    foreach ($dias as $dia) {
        if ($dia === $esperado->format('Y-m-d')) {
            $racha++;
            $esperado->modify('-1 day');
        } else {
            break;
        }
    }
    return $racha;
}


function actualizarRacha(PDO $pdo, int $id_habito, int $id_usuario): int
{
    $racha = calcularRachaActual($pdo, $id_habito, $id_usuario);
    $pdo->prepare(
        "UPDATE habitos
         SET racha_actual = :r,
             racha_maxima = GREATEST(racha_maxima, :r)
         WHERE id = :h AND id_usuario = :u"
    )->execute([':r' => $racha, ':h' => $id_habito, ':u' => $id_usuario]);
    return $racha;
}


function evaluarInsignias(PDO $pdo, int $id_usuario): array
{
    $nuevas = [];

    // Insignia: 7 días de racha en cualquier hábito
    $stmt = $pdo->prepare(
        "SELECT id FROM habitos WHERE id_usuario = :u AND racha_actual >= 7 AND archivado = 0"
    );
    $stmt->execute([':u' => $id_usuario]);
    if ($stmt->fetchColumn()) {
        if (otorgarInsignia($pdo, $id_usuario, 1))
            $nuevas[] = '🔥 Primera Semana';
    }

    $stmt = $pdo->prepare(
        "SELECT id FROM habitos WHERE id_usuario = :u AND racha_actual >= 30 AND archivado = 0"
    );
    $stmt->execute([':u' => $id_usuario]);
    if ($stmt->fetchColumn()) {
        if (otorgarInsignia($pdo, $id_usuario, 2))
            $nuevas[] = '🌟 Mes Constante';
    }

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM completaciones WHERE id_usuario = :u AND anulado = 0"
    );
    $stmt->execute([':u' => $id_usuario]);
    if ((int) $stmt->fetchColumn() >= 100) {
        if (otorgarInsignia($pdo, $id_usuario, 3))
            $nuevas[] = '💯 Centenario';
    }

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM completaciones
         WHERE id_usuario = :u AND HOUR(completado_en) < 8 AND anulado = 0"
    );
    $stmt->execute([':u' => $id_usuario]);
    if ((int) $stmt->fetchColumn() > 0) {
        if (otorgarInsignia($pdo, $id_usuario, 4))
            $nuevas[] = '🌅 Madrugador';
    }

    return $nuevas;
}


function otorgarInsignia(PDO $pdo, int $id_usuario, int $id_insignia): bool
{
    try {
        $pdo->prepare(
            "INSERT IGNORE INTO usuario_insignias (id_usuario, id_insignia) VALUES (:u, :i)"
        )->execute([':u' => $id_usuario, ':i' => $id_insignia]);
        return $pdo->lastInsertId() > 0;
    } catch (PDOException $e) {
        return false;
    }
}


function obtenerInsignias(PDO $pdo, int $id_usuario): array
{
    $stmt = $pdo->prepare(
        "SELECT i.nombre, i.descripcion, i.icono, ui.obtenida_en
         FROM usuario_insignias ui
         JOIN insignias i ON i.id = ui.id_insignia
         WHERE ui.id_usuario = :u
         ORDER BY ui.obtenida_en DESC"
    );
    $stmt->execute([':u' => $id_usuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function habitoEsParaFecha(array $habito, string $fecha): bool
{
    $fechaObj = new DateTime($fecha);
    // Para inicio, solo considerar la fecha sin horas
    $inicioStr = $habito['fecha_inicio'] ?? date('Y-m-d');
    $inicioObj = new DateTime($inicioStr);

    if ($fechaObj < $inicioObj) {
        return false;
    }

    if (!empty($habito['meta_fecha_limite'])) {
        $limiteObj = new DateTime($habito['meta_fecha_limite']);
        if ($fechaObj > $limiteObj) {
            return false;
        }
    }

    $tipo = $habito['frequency_type'] ?? 'DIARIO';
    $params = json_decode($habito['frequency_params'] ?? '{}', true) ?: [];

    if ($tipo === 'DIARIO')
        return true;

    if ($tipo === 'SEMANAL') {
        $diasPermitidos = $params['dias'] ?? [1, 2, 3, 4, 5, 6, 7];
        $diaSemana = (int) $fechaObj->format('N'); // 1=Lun … 7=Dom
        return in_array($diaSemana, $diasPermitidos);
    }

    if ($tipo === 'PERSONALIZADO') {
        $cadaN = (int) ($params['cada_n_dias'] ?? 1);
        $diff = (int) $inicioObj->diff($fechaObj)->days;
        return $cadaN > 0 && ($diff % $cadaN === 0);
    }

    return true;
}

/**
 * Wrapper para el día de HOY.
 */
function habitoEsHoy(array $habito): bool
{
    return habitoEsParaFecha($habito, date('Y-m-d'));
}


function filtrarHabitosDeHoy(array $habitos): array
{
    return array_filter($habitos, fn($h) => habitoEsHoy($h) && !$h['archivado']);
}


function sumarXP($pdo, $id_usuario, $cantidad)
{
    // 1. Obtener datos actuales del usuario
    $stmt = $pdo->prepare("SELECT xp, nivel, nombre FROM usuarios WHERE id = :id");
    $stmt->execute([':id' => $id_usuario]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user)
        return null;

    $nuevoXP = (int) $user['xp'] + $cantidad;
    $nivelActual = (int) $user['nivel'];
    $subioNivel = false;

    $xpNecesario = $nivelActual * 100;

    if ($nuevoXP >= $xpNecesario) {
        $nuevoXP -= $xpNecesario;
        $nivelActual++;
        $subioNivel = true;
    }

    $stmtU = $pdo->prepare("UPDATE usuarios SET xp = :xp, nivel = :n WHERE id = :id");
    $stmtU->execute([
        ':xp' => $nuevoXP,
        ':n' => $nivelActual,
        ':id' => $id_usuario
    ]);

    return [
        'xp_ganado' => $cantidad,
        'xp_actual' => $nuevoXP,
        'xp_objetivo' => ($nivelActual * 100),
        'nivel' => $nivelActual,
        'subio_nivel' => $subioNivel
    ];
}

