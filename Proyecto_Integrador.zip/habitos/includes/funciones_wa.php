<?php
require_once __DIR__ . '/config_wa.php';

function enviarWhatsApp($numero, $mensaje)
{
    $numero = preg_replace('/[^0-9]/', '', $numero);

    $chatId = $numero . "@c.us";

    $url = WA_API_URL . "/waInstance" . WA_ID_INSTANCE . "/sendMessage/" . WA_API_TOKEN;

    $data = [
        "chatId" => $chatId,
        "message" => $mensaje
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'error' => "CURL Error: " . $error];
    }

    $resDecoded = json_decode($response, true);

    if ($httpCode === 200 && isset($resDecoded['idMessage'])) {
        return ['success' => true, 'response' => $resDecoded];
    }

    return [
        'success' => false,
        'error' => "API Error (Code $httpCode): " . ($response ?: 'Sin respuesta del servidor')
    ];
}
