<nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
  <div class="container">
    <div class="navbar-brand">
      <a class="navbar-item" href="/WebPageUpdate/habitos/home/index.php">
        <span class="material-symbols-outlined" style="margin-right: 8px;">eco</span>
        HabitFlow
      </a>
      <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
      <div class="navbar-start">
        <?php
        // Cargar estadísticas de gamificación en tiempo real
        $stmtStats = $pdo->prepare("SELECT xp, nivel FROM usuarios WHERE id = :id");
        $stmtStats->execute([':id' => $_SESSION['usuario_id']]);
        $stats = $stmtStats->fetch();
        $userXP = (int)($stats['xp'] ?? 0);
        $userNivel = (int)($stats['nivel'] ?? 1);
        $xpSigNivel = $userNivel * 100;
        $pctXP = ($userXP / $xpSigNivel) * 100;
        ?>
        <div class="navbar-item">
            <div class="is-flex is-align-items-center" style="gap: 10px;">
                <span class="tag is-primary is-rounded has-text-weight-bold" id="nav-user-level">Nivel <?php echo $userNivel; ?></span>
                <div style="width: 120px;">
                    <progress class="progress is-info is-small" id="nav-xp-bar" value="<?php echo $userXP; ?>" max="<?php echo $xpSigNivel; ?>"><?php echo $pctXP; ?>%</progress>
                    <p class="is-size-7 has-text-grey" style="margin-top: -12px;"><span id="nav-xp-val"><?php echo $userXP; ?></span>/<?php echo $xpSigNivel; ?> XP</p>
                </div>
            </div>
        </div>
      </div>

      <div class="navbar-end">
        <a href="/WebPageUpdate/habitos/home/index.php" class="navbar-item">Dashboard</a>
        <?php if (esAdmin()): ?>
        <a href="/WebPageUpdate/habitos/home/usuarios/index.php" class="navbar-item">Usuarios</a>
        <?php endif; ?>
        <a href="/WebPageUpdate/habitos/home/habitos/index.php" class="navbar-item">Mis Hábitos</a>
        <a href="/WebPageUpdate/habitos/home/calendario.php" class="navbar-item">Calendario</a>
        <a href="/WebPageUpdate/habitos/home/habitos/reporte_semanal.php" class="navbar-item">Reportes</a>
        <a href="/WebPageUpdate/habitos/home/metas/index.php" class="navbar-item">Metas</a>
        
        <div class="navbar-item">
          <div class="buttons">
            <a href="/WebPageUpdate/habitos/logout.php" class="button is-light">
              Salir
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</nav>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
  if ($navbarBurgers.length > 0) {
    $navbarBurgers.forEach( el => {
      el.addEventListener('click', () => {
        const target = el.dataset.target;
        const $target = document.getElementById(target);
        el.classList.toggle('is-active');
        $target.classList.toggle('is-active');
      });
    });
  }
});
</script>
