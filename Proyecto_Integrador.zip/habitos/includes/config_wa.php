<?php
define('WA_ID_INSTANCE', '7107607357');
define('WA_API_TOKEN', 'e89163db01c74aff9ed38019abb28a62f08caaf1e6044fdeb2');
define('WA_API_URL', 'https://7107.api.greenapi.com');
