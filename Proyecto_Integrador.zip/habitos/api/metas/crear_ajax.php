<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = (int)$_SESSION['usuario_id'];
    $data = json_decode(file_get_contents('php://input'), true);
    
    $titulo = limpiar($data['titulo'] ?? '');
    $descripcion = limpiar($data['descripcion'] ?? '');
    $fecha_inicio = empty($data['fecha_inicio']) ? date('Y-m-d') : $data['fecha_inicio'];
    $fecha_limite = empty($data['fecha_limite']) ? null : $data['fecha_limite'];

    if (empty($titulo)) {
        echo json_encode(['error' => 'El título es obligatorio']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO metas (id_usuario, titulo, descripcion, fecha_inicio, fecha_limite) VALUES (:u, :t, :d, :fi, :fl)");
        $stmt->execute([
            ':u' => $id_usuario,
            ':t' => $titulo,
            ':d' => $descripcion,
            ':fi' => $fecha_inicio,
            ':fl' => $fecha_limite
        ]);
        
        $id = $pdo->lastInsertId();
        echo json_encode(['success' => true, 'id' => $id, 'titulo' => $titulo]);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
}
