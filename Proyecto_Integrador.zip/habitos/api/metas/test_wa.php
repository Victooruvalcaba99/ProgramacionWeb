<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/conexion.php';
require_once __DIR__ . '/../../includes/funciones_wa.php';
require_once __DIR__ . '/../../includes/helpers.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id_meta = (int)($data['id_meta'] ?? 0);
    $numero = limpiar($data['numero'] ?? '');
    
    if (empty($numero)) {
        echo json_encode(['success' => false, 'error' => 'El número no puede estar vacío']);
        exit;
    }

    // Buscar info de la meta
    $stmt = $pdo->prepare("SELECT titulo FROM metas WHERE id = :id AND id_usuario = :u");
    $stmt->execute([':id' => $id_meta, ':u' => $_SESSION['usuario_id']]);
    $meta = $stmt->fetch();
    
    $titulo = $meta ? $meta['titulo'] : 'Tu Meta';
    $mensaje = "🧪 *Prueba de Notificación HabitFlow*\n\nSi recibiste esto, ¡tu integración con WhatsApp está lista para la meta: *$titulo*! 🚀";

    $resultado = enviarWhatsApp($numero, $mensaje);
    
    echo json_encode($resultado);
}
