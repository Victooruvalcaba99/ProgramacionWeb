<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/conexion.php';

header('Content-Type: application/json');

$id_usuario = (int)$_SESSION['usuario_id'];

// Determinar ventana de 7 días
$stmt = $pdo->prepare("SELECT MIN(fecha_inicio) FROM habitos WHERE id_usuario = :u AND archivado = 0");
$stmt->execute([':u' => $id_usuario]);
$fecha_primer_habito = $stmt->fetchColumn() ?: date('Y-m-d');
$inicio_rango = strtotime(max($fecha_primer_habito, date('Y-m-d', strtotime('-6 days'))));

$stmt = $pdo->prepare("
    SELECT h.id, h.fecha_inicio, m.fecha_limite AS meta_fecha_limite 
    FROM habitos h 
    LEFT JOIN metas m ON h.id_meta = m.id 
    WHERE h.id_usuario = :u AND h.archivado = 0
");
$stmt->execute([':u' => $id_usuario]);
$habitos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmtC = $pdo->prepare("SELECT id_habito, DATE(completado_en) as dia FROM completaciones WHERE id_usuario = :u AND anulado = 0");
$stmtC->execute([':u' => $id_usuario]);
$completaciones = $stmtC->fetchAll(PDO::FETCH_ASSOC);

$comps = [];
foreach ($completaciones as $c) {
    $comps[$c['id_habito']][$c['dia']] = true;
}

$fechas = [];
$completados = [];
$missed = [];
$hoy = date('Y-m-d');

for ($i = 0; $i < 7; $i++) {
    $fecha = date('Y-m-d', strtotime("+$i days", $inicio_rango));
    $fechas[] = date('D', strtotime($fecha));
    
    $activos_dia = 0;
    $comps_dia = 0;
    
    foreach ($habitos as $h) {
        if ($fecha >= $h['fecha_inicio'] && $fecha <= $hoy) {
            $activos_dia++;
            if (isset($comps[$h['id']][$fecha])) {
                $comps_dia++;
            }
        }
    }
    
    $completados[] = $comps_dia;
    $missed[] = max(0, $activos_dia - $comps_dia);
}

echo json_encode([
    'dates' => $fechas,
    'completed' => $completados,
    'missed' => $missed
]);
