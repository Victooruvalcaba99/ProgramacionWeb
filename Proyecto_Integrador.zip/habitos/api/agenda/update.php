<?php
require_once __DIR__ . '/../../includes/verificar_sesion.php';
require_once __DIR__ . '/../../includes/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$id_usuario = (int)$_SESSION['usuario_id'];
$id_habito  = (int)($data['id_habito'] ?? 0);
$fecha      = $data['fecha'] ?? '';
$hora       = isset($data['hora']) ? (int)$data['hora'] : null;

if (!$id_habito || !$fecha) {
    echo json_encode(['error' => 'Missing data']);
    exit;
}

try {
    if ($hora === null || $hora < 0) {
        // Remove from agenda (unassign)
        $stmt = $pdo->prepare("DELETE FROM agenda_diaria WHERE id_usuario = :u AND id_habito = :h AND fecha = :f");
        $stmt->execute([':u' => $id_usuario, ':h' => $id_habito, ':f' => $fecha]);
    } else {
        // Add/Update agenda
        $stmt = $pdo->prepare("
            INSERT INTO agenda_diaria (id_usuario, id_habito, fecha, hora) 
            VALUES (:u, :h, :f, :ho)
            ON DUPLICATE KEY UPDATE hora = VALUES(hora)
        ");
        $stmt->execute([':u' => $id_usuario, ':h' => $id_habito, ':f' => $fecha, ':ho' => $hora]);
    }
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
