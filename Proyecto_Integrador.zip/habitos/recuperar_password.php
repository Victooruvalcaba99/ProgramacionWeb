<?php
// recuperar_password.php  —  placeholder para recuperación de contraseña
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña | LexEconomica</title>
    <link rel="stylesheet" href="/WebPageUpdate/habitos/assets/css/style.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-container">
            <div class="card-header">
                <h1>Recuperar Contraseña</h1>
                <p>Ingresa tu usuario y te enviaremos instrucciones.</p>
            </div>
            <form method="post">
                <div class="form-group">
                    <label for="usuario">Usuario</label>
                    <div class="input-wrapper">
                        <input type="text" name="usuario" id="usuario" placeholder="Tu usuario" required>
                    </div>
                </div>
                <input type="submit" value="Enviar →">
            </form>
            <p style="text-align:center;margin-top:20px;">
                <a href="/WebPageUpdate/habitos/index.php" style="color:#818cf8;">← Volver al login</a>
            </p>
        </div>
    </div>
</body>
</html>
