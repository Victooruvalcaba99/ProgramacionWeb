<?php
/**
 * Script para procesar notificaciones programadas de WhatsApp
 * Se recomienda ejecutar cada minuto vía Cron
 */
require_once __DIR__ . '/../includes/conexion.php';
require_once __DIR__ . '/../includes/funciones_wa.php';
require_once __DIR__ . '/../includes/helpers.php';

// Obtener hora actual (HH:mm)
date_default_timezone_set('America/Mexico_City');
$horaActual = date('H:i');

echo "Iniciando procesamiento de alertas - $horaActual\n";

// Buscar metas activas con notificaciones programadas para esta hora
$stmt = $pdo->prepare("
    SELECT m.*, u.nombre as nombre_usuario 
    FROM metas m
    JOIN usuarios u ON m.id_usuario = u.id
    WHERE m.wa_frecuencia != 'DESACTIVADO' 
      AND m.wa_hora LIKE :h
      AND m.wa_numero IS NOT NULL
      AND m.completada = 0
");

// Buscamos coincidencia de Hora:Minuto
$stmt->execute([':h' => $horaActual . '%']);
$metas = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($metas as $m) {
    echo "Procesando meta: " . $m['titulo'] . " para " . $m['wa_numero'] . "\n";
    
    // Construir mensaje motivador
    $mensaje = "¡Hola " . $m['nombre_usuario'] . "! 👋\n\n";
    $mensaje .= "Es hora de trabajar en tu meta: *" . $m['titulo'] . "* 🎯\n";
    
    if ($m['descripcion']) {
        $mensaje .= "Recuerda: _" . $m['descripcion'] . "_\n";
    }
    
    $mensaje .= "\n¡No te rindas! HabitFlow te acompaña. 🔥";
    
    // Enviar
    $resultado = enviarWhatsApp($m['wa_numero'], $mensaje);
    
    if ($resultado['success']) {
        echo "✅ Mensaje enviado correctamente.\n";
    } else {
        echo "❌ Error al enviar: " . $resultado['error'] . "\n";
    }
}

echo "Fin del proceso.\n";
