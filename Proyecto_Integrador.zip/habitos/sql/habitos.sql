-- Tabla de roles
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

INSERT INTO roles (id, nombre) VALUES (1, 'Administrador'), (2, 'Becario');

-- Tabla de usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    id_rol INT NOT NULL DEFAULT 2,
    xp INT DEFAULT 0,
    nivel INT DEFAULT 1,
    puntos INT DEFAULT 0,
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_rol) REFERENCES roles(id)
);

-- Tabla de habitos
CREATE TABLE habitos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_meta INT DEFAULT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    frequency_type ENUM('DIARIO', 'SEMANAL', 'PERSONALIZADO') NOT NULL DEFAULT 'DIARIO',
    frequency_params JSON,
    meta_cantidad TINYINT UNSIGNED DEFAULT 1,
    racha_actual INT UNSIGNED DEFAULT 0,
    racha_maxima INT UNSIGNED DEFAULT 0,
    archivado TINYINT(1) DEFAULT 0,
    fecha_inicio DATE,
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabla de completaciones
CREATE TABLE completaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_habito INT NOT NULL,
    id_usuario INT NOT NULL,
    completado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    anulado TINYINT(1) DEFAULT 0,
    FOREIGN KEY (id_habito) REFERENCES habitos(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_habito_fecha (id_habito, completado_en),
    INDEX idx_usuario_fecha (id_usuario, completado_en)
);

-- Tabla de metas
CREATE TABLE metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE,
    fecha_limite DATE,
    completada TINYINT(1) DEFAULT 0,
    wa_numero VARCHAR(20) DEFAULT NULL,
    wa_hora TIME DEFAULT NULL,
    wa_frecuencia VARCHAR(20) DEFAULT 'DESACTIVADO',
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Foreign key de habitos a metas (se agrega despues porque metas se crea despues)
ALTER TABLE habitos ADD FOREIGN KEY (id_meta) REFERENCES metas(id) ON DELETE SET NULL;

-- Tabla de insignias
CREATE TABLE insignias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    descripcion VARCHAR(255),
    icono VARCHAR(10) DEFAULT '🏅',
    criterio VARCHAR(100)
);

-- Tabla de insignias de usuarios
CREATE TABLE usuario_insignias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_insignia INT NOT NULL,
    obtenida_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_insignia) REFERENCES insignias(id) ON DELETE CASCADE,
    UNIQUE KEY uq_usuario_insignia (id_usuario, id_insignia)
);

-- Insignias base del sistema
INSERT INTO insignias (id, nombre, descripcion, icono, criterio) VALUES
(1, 'Primera Semana', '7 dias consecutivos completando un habito', '🔥', 'racha_7'),
(2, 'Mes Constante', '30 dias de racha en cualquier habito', '🌟', 'racha_30'),
(3, 'Centenario', '100 completaciones totales', '💯', 'completaciones_100'),
(4, 'Madrugador', 'Completar un habito antes de las 8 am', '🌅', 'antes_8am'),
(5, 'Racha Perfecta', 'Semana completa sin fallar ningun habito', '🏆', 'semana_perfecta');

-- Tabla de agenda diaria (calendario)
CREATE TABLE agenda_diaria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_habito INT NOT NULL,
    fecha DATE NOT NULL,
    hora TINYINT NOT NULL,
    UNIQUE KEY uq_agenda (id_usuario, id_habito, fecha),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_habito) REFERENCES habitos(id) ON DELETE CASCADE
);
